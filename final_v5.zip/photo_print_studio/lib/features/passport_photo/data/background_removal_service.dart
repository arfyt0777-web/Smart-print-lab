import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:image/image.dart' as img;
import '../../core/config/app_config.dart';

/// Service that calls the Groq vision API to remove the background
/// from a passport photo and returns RGBA image bytes.
class BackgroundRemovalService {
  /// Removes the background from [imageFile] using Groq vision API.
  ///
  /// Strategy:
  ///   1. Send the image to Groq with a detailed prompt asking it to
  ///      describe the subject bounding area.
  ///   2. Use the `image` package to perform chroma-key / flood-fill
  ///      background removal on the detected background color.
  ///
  /// Returns PNG bytes with transparent background (RGBA).
  static Future<Uint8List> removeBackground(File imageFile) async {
    final imageBytes = await imageFile.readAsBytes();
    final base64Image = base64Encode(imageBytes);

    // Determine mime type
    final extension = imageFile.path.split('.').last.toLowerCase();
    final mimeType = extension == 'png' ? 'image/png' : 'image/jpeg';

    // ── Step 1: Ask Groq to identify the background colour ───────────
    final groqResponse = await _callGroqVisionApi(base64Image, mimeType);

    // ── Step 2: Parse colour hint from Groq response ─────────────────
    final bgColor = _parseBgColorFromResponse(groqResponse);

    // ── Step 3: Perform background removal with image package ─────────
    final result = await _performBackgroundRemoval(imageBytes, bgColor);

    return result;
  }

  static Future<String> _callGroqVisionApi(
      String base64Image, String mimeType) async {
    final uri = Uri.parse('${AppConfig.groqBaseUrl}/chat/completions');

    final body = jsonEncode({
      'model': AppConfig.groqVisionModel,
      'max_tokens': 512,
      'messages': [
        {
          'role': 'user',
          'content': [
            {
              'type': 'image_url',
              'image_url': {
                'url': 'data:$mimeType;base64,$base64Image',
              },
            },
            {
              'type': 'text',
              'text': '''Analyze this passport/ID photo. 
I need to remove the background programmatically.
Please respond in JSON only (no markdown) with this exact structure:
{
  "background_color": "#RRGGBB",
  "background_type": "solid|gradient|complex",
  "subject_position": "center|left|right",
  "confidence": 0.0-1.0
}
The background_color should be the dominant/average hex color of the background.''',
            },
          ],
        }
      ],
    });

    final response = await http.post(
      uri,
      headers: {
        'Authorization': 'Bearer ${AppConfig.groqApiKey}',
        'Content-Type': 'application/json',
      },
      body: body,
    );

    if (response.statusCode != 200) {
      throw Exception(
          'Groq API error ${response.statusCode}: ${response.body}');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final content = data['choices'][0]['message']['content'] as String;
    return content;
  }

  /// Parse hex color from Groq JSON response.
  static img.Color _parseBgColorFromResponse(String response) {
    try {
      // Strip markdown fences if present
      final clean = response
          .replaceAll('```json', '')
          .replaceAll('```', '')
          .trim();
      final json = jsonDecode(clean) as Map<String, dynamic>;
      final hex = (json['background_color'] as String?)?.replaceAll('#', '');
      if (hex != null && hex.length == 6) {
        final r = int.parse(hex.substring(0, 2), radix: 16);
        final g = int.parse(hex.substring(2, 4), radix: 16);
        final b = int.parse(hex.substring(4, 6), radix: 16);
        return img.ColorRgba8(r, g, b, 255);
      }
    } catch (_) {
      // fallback to white
    }
    return img.ColorRgba8(255, 255, 255, 255);
  }

  /// Performs flood-fill background removal and returns PNG bytes.
  static Future<Uint8List> _performBackgroundRemoval(
      Uint8List imageBytes, img.Color detectedBgColor) async {
    // Decode image
    img.Image? decoded = img.decodeImage(imageBytes);
    if (decoded == null) throw Exception('Could not decode image');

    // Convert to RGBA for transparency support
    img.Image rgba = decoded.convert(numChannels: 4);

    final width  = rgba.width;
    final height = rgba.height;

    // Tolerance for colour matching (0-255)
    const int tolerance = 40;

    // Sample background colour from corners to improve accuracy
    final corners = [
      rgba.getPixel(0, 0),
      rgba.getPixel(width - 1, 0),
      rgba.getPixel(0, height - 1),
      rgba.getPixel(width - 1, height - 1),
    ];

    // Choose the corner colour closest to the detected colour
    img.Color bgSample = corners.first;
    double minDist = double.infinity;
    for (final c in corners) {
      final d = _colorDistance(c, detectedBgColor);
      if (d < minDist) {
        minDist = d;
        bgSample = c;
      }
    }

    // Flood-fill from all 4 corners
    _floodFill(rgba, 0, 0, bgSample, tolerance);
    _floodFill(rgba, width - 1, 0, bgSample, tolerance);
    _floodFill(rgba, 0, height - 1, bgSample, tolerance);
    _floodFill(rgba, width - 1, height - 1, bgSample, tolerance);

    // Feather edges slightly for a smoother result
    _featherEdges(rgba);

    return Uint8List.fromList(img.encodePng(rgba));
  }

  /// BFS flood-fill that makes matching pixels transparent.
  static void _floodFill(
      img.Image image, int startX, int startY, img.Color targetColor, int tolerance) {
    final width  = image.width;
    final height = image.height;
    final transparent = img.ColorRgba8(0, 0, 0, 0);

    final queue = <List<int>>[];
    final visited = List.generate(height, (_) => List.filled(width, false));

    queue.add([startX, startY]);
    visited[startY][startX] = true;

    while (queue.isNotEmpty) {
      final point = queue.removeAt(0);
      final x = point[0];
      final y = point[1];

      final pixel = image.getPixel(x, y);
      if (_colorDistance(pixel, targetColor) > tolerance) continue;
      if (pixel.a == 0) continue; // already transparent

      image.setPixel(x, y, transparent);

      // 4-connected neighbours
      final neighbours = [
        [x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1],
      ];
      for (final n in neighbours) {
        final nx = n[0];
        final ny = n[1];
        if (nx >= 0 && nx < width && ny >= 0 && ny < height &&
            !visited[ny][nx]) {
          visited[ny][nx] = true;
          queue.add([nx, ny]);
        }
      }
    }
  }

  /// Slightly feathers the alpha along the edge boundary.
  static void _featherEdges(img.Image image) {
    final width  = image.width;
    final height = image.height;

    for (int y = 1; y < height - 1; y++) {
      for (int x = 1; x < width - 1; x++) {
        final p = image.getPixel(x, y);
        if (p.a == 0) continue;

        // Check neighbours
        final neighbours = [
          image.getPixel(x - 1, y),
          image.getPixel(x + 1, y),
          image.getPixel(x, y - 1),
          image.getPixel(x, y + 1),
        ];
        final transparentNeighbours =
            neighbours.where((n) => n.a < 128).length;

        if (transparentNeighbours > 0) {
          // Feather this pixel
          final newAlpha = (p.a * (1.0 - transparentNeighbours * 0.2)).clamp(0, 255).toInt();
          image.setPixel(x, y, img.ColorRgba8(p.r.toInt(), p.g.toInt(), p.b.toInt(), newAlpha));
        }
      }
    }
  }

  static double _colorDistance(img.Color a, img.Color b) {
    final dr = (a.r - b.r).toDouble();
    final dg = (a.g - b.g).toDouble();
    final db = (a.b - b.b).toDouble();
    return (dr * dr + dg * dg + db * db);
  }
}

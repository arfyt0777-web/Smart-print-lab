import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../shared/widgets/loading_overlay.dart';
import 'background_screen.dart';

class CaptureScreen extends StatefulWidget {
  const CaptureScreen({super.key});

  @override
  State<CaptureScreen> createState() => _CaptureScreenState();
}

class _CaptureScreenState extends State<CaptureScreen> {
  final _picker = ImagePicker();
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: _isLoading,
      message: 'Preparing image…',
      child: Scaffold(
        backgroundColor: AppTheme.surface,
        appBar: AppBar(
          title: const Text('Passport Photo Maker'),
          leading: const BackButton(),
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const SizedBox(height: 16),
                _buildHeroIllustration(),
                const SizedBox(height: 32),
                _buildTitle(),
                const SizedBox(height: 40),
                _buildActionButtons(context),
                const Spacer(),
                _buildTips(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeroIllustration() {
    return Container(
      width: 140,
      height: 140,
      decoration: BoxDecoration(
        color: AppTheme.primary.withOpacity(0.08),
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Container(
          width: 100,
          height: 100,
          decoration: BoxDecoration(
            color: AppTheme.primary.withOpacity(0.12),
            shape: BoxShape.circle,
          ),
          child: const Icon(
            Icons.face_outlined,
            size: 56,
            color: AppTheme.primary,
          ),
        ),
      ),
    );
  }

  Widget _buildTitle() {
    return Column(
      children: [
        const Text(
          'Add Your Photo',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w800,
            color: AppTheme.textPrimary,
            letterSpacing: -0.5,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Take a new photo or choose one from your gallery.\nAI will remove the background automatically.',
          style: const TextStyle(
            fontSize: 14,
            color: AppTheme.textSecondary,
            height: 1.5,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: () => _captureFromCamera(context),
            icon: const Icon(Icons.camera_alt_outlined),
            label: const Text('Take a Photo'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primary,
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () => _pickFromGallery(context),
            icon: const Icon(Icons.photo_library_outlined),
            label: const Text('Choose from Gallery'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTips() {
    final tips = [
      '📸  Face the camera directly',
      '💡  Use good, even lighting',
      '⚪  Plain or light background works best',
    ];
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.primary.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.primary.withOpacity(0.15)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Tips for best results',
              style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                  color: AppTheme.primary)),
          const SizedBox(height: 8),
          ...tips.map((t) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(t,
                    style: const TextStyle(
                        fontSize: 13, color: AppTheme.textSecondary)),
              )),
        ],
      ),
    );
  }

  // ── Camera ──────────────────────────────────────────────────────────
  Future<void> _captureFromCamera(BuildContext context) async {
    final status = await Permission.camera.request();
    if (!status.isGranted) {
      _showPermissionDenied('Camera');
      return;
    }
    await _pickImage(ImageSource.camera, context);
  }

  // ── Gallery ─────────────────────────────────────────────────────────
  Future<void> _pickFromGallery(BuildContext context) async {
    final status = await Permission.photos.request();
    if (!status.isGranted && !status.isLimited) {
      _showPermissionDenied('Gallery');
      return;
    }
    await _pickImage(ImageSource.gallery, context);
  }

  Future<void> _pickImage(ImageSource source, BuildContext context) async {
    final xFile = await _picker.pickImage(
      source: source,
      imageQuality: 100, // No compression
    );
    if (xFile == null) return;

    final file = File(xFile.path);
    if (!mounted) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BackgroundScreen(imageFile: file),
      ),
    );
  }

  void _showPermissionDenied(String type) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('$type Permission Required'),
        content: Text(
            'Please allow $type access in Settings to use this feature.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              openAppSettings();
            },
            child: const Text('Open Settings'),
          ),
        ],
      ),
    );
  }
}

import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../shared/widgets/loading_overlay.dart';
import '../../data/sheet_generator_service.dart';
import '../../data/pdf_export_service.dart';

class SheetScreen extends StatefulWidget {
  final Uint8List processedPng;
  final Color bgColor;

  const SheetScreen({
    super.key,
    required this.processedPng,
    required this.bgColor,
  });

  @override
  State<SheetScreen> createState() => _SheetScreenState();
}

class _SheetScreenState extends State<SheetScreen> {
  int _photoCount = 4;
  Uint8List? _sheetPng;
  bool _isGenerating = false;
  bool _isExporting = false;
  String _loadingMessage = 'Generating sheet…';

  final List<int> _countOptions = [2, 4, 6, 8, 10, 12];

  @override
  void initState() {
    super.initState();
    _generateSheet();
  }

  Future<void> _generateSheet() async {
    setState(() { _isGenerating = true; _loadingMessage = 'Generating sheet…'; });
    try {
      final sheet = await SheetGeneratorService.generateSheet(
        subjectPng: widget.processedPng,
        bgColor: widget.bgColor,
        photoCount: _photoCount,
      );
      if (mounted) setState(() { _sheetPng = sheet; _isGenerating = false; });
    } catch (e) {
      if (mounted) {
        setState(() => _isGenerating = false);
        _showSnack('Sheet generation failed: $e', isError: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: _isGenerating || _isExporting,
      message: _loadingMessage,
      child: Scaffold(
        backgroundColor: AppTheme.surface,
        appBar: AppBar(title: const Text('Print Sheet')),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildCountSelector(),
                const SizedBox(height: 24),
                _buildSheetPreview(),
                const SizedBox(height: 24),
                _buildExportSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCountSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Number of Photos',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimary)),
        const SizedBox(height: 4),
        const Text('Select how many photos to print on the 4×6 sheet',
            style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
        const SizedBox(height: 12),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: _countOptions.map((n) {
            final selected = n == _photoCount;
            return GestureDetector(
              onTap: () {
                if (selected) return;
                setState(() => _photoCount = n);
                _generateSheet();
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: selected ? AppTheme.primary : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: selected ? AppTheme.primary : AppTheme.border,
                    width: 1.5,
                  ),
                  boxShadow: selected
                      ? [
                          BoxShadow(
                            color: AppTheme.primary.withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 3),
                          )
                        ]
                      : [],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('$n',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          color: selected ? Colors.white : AppTheme.textPrimary,
                        )),
                    Text('photos',
                        style: TextStyle(
                          fontSize: 9,
                          color: selected
                              ? Colors.white.withOpacity(0.8)
                              : AppTheme.textSecondary,
                        )),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildSheetPreview() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Sheet Preview',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary)),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppTheme.success.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text('4×6 inch',
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.success)),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.grey[200],
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.border),
          ),
          child: AspectRatio(
            aspectRatio: 4 / 6,
            child: _sheetPng != null
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: Image.memory(_sheetPng!, fit: BoxFit.cover),
                  )
                : const Center(
                    child: CircularProgressIndicator(color: AppTheme.primary),
                  ),
          ),
        ),
      ],
    );
  }

  Widget _buildExportSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Export & Print',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimary)),
        const SizedBox(height: 12),
        // Row 1 — Save & Print
        Row(
          children: [
            Expanded(
              child: _ExportButton(
                icon: Icons.save_alt_outlined,
                label: 'Save to Gallery',
                sublabel: 'High-quality JPG',
                color: AppTheme.success,
                onTap: _saveToGallery,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _ExportButton(
                icon: Icons.print_outlined,
                label: 'Print',
                sublabel: 'WiFi / Bluetooth',
                color: AppTheme.primary,
                onTap: _printSheet,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        // Row 2 — PDF
        SizedBox(
          width: double.infinity,
          child: _ExportButton(
            icon: Icons.picture_as_pdf_outlined,
            label: 'Download as PDF',
            sublabel: 'Print-ready 4×6 PDF',
            color: AppTheme.error,
            onTap: _downloadAsPdf,
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  // ── Export actions ───────────────────────────────────────────────────

  Future<void> _saveToGallery() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMessage = 'Saving to gallery…'; });
    try {
      // Write PNG to temp file then save via gal
      final dir  = await getTemporaryDirectory();
      final file = File('${dir.path}/passport_sheet_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await file.writeAsBytes(_sheetPng!);
      await Gal.putImage(file.path, album: 'Photo Print Studio');
      if (mounted) _showSnack('✅  Saved to gallery!');
    } catch (e) {
      if (mounted) _showSnack('Save failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _printSheet() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMessage = 'Preparing print…'; });
    try {
      final pdf = await PdfExportService.generatePdf(_sheetPng!);
      final pdfBytes = await pdf.readAsBytes();
      await Printing.layoutPdf(
        onLayout: (_) async => pdfBytes,
        name: 'Passport Photo Sheet',
      );
    } catch (e) {
      if (mounted) _showSnack('Print failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _downloadAsPdf() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMessage = 'Generating PDF…'; });
    try {
      final pdf = await PdfExportService.generatePdf(_sheetPng!);

      // Share / open the PDF using the printing package's share dialog
      await Printing.sharePdf(
        bytes: await pdf.readAsBytes(),
        filename: 'passport_sheet.pdf',
      );
    } catch (e) {
      if (mounted) _showSnack('PDF export failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: isError ? AppTheme.error : AppTheme.success,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}

// ── Export Button Widget ─────────────────────────────────────────────────────

class _ExportButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final String sublabel;
  final Color color;
  final VoidCallback onTap;

  const _ExportButton({
    required this.icon,
    required this.label,
    required this.sublabel,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.25), width: 1.5),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: color)),
                Text(sublabel,
                    style: const TextStyle(
                        fontSize: 11, color: AppTheme.textSecondary)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

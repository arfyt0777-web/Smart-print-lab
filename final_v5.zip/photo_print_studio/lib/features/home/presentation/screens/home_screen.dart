import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../passport_photo/presentation/screens/capture_screen.dart';
import '../../cards_print/presentation/screens/cards_home_screen.dart';
import '../../printer_scan/presentation/screens/printer_scan_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surface,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(child: _buildModuleGrid(context)),
            _buildFooter(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 32, 24, 24),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: AppTheme.border)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppTheme.primary,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.photo_camera, color: Colors.white, size: 24),
          ),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Photo Print Studio',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.textPrimary,
                  letterSpacing: -0.5,
                ),
              ),
              Text(
                'Professional photo tools',
                style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildModuleGrid(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Select a Module',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            '3 modules available',
            style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
          ),
          const SizedBox(height: 16),

          // MODULE 1
          _ModuleCard(
            icon: Icons.badge_outlined,
            title: 'Passport Photo Maker',
            description: 'AI background removal, choose size & print on 4x6 sheet',
            color: AppTheme.primary,
            badgeNum: '1',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const CaptureScreen())),
          ),
          const SizedBox(height: 12),

          // MODULE 2
          _ModuleCard(
            icon: Icons.credit_card_outlined,
            title: 'Cards Print',
            description: 'Aadhaar, PAN, Ration & ID cards — crop, arrange & print',
            color: const Color(0xFF7C3AED),
            badgeNum: '2',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const CardsHomeScreen())),
          ),
          const SizedBox(height: 12),

          // MODULE 3
          _ModuleCard(
            icon: Icons.document_scanner_outlined,
            title: 'Printer Scan',
            description: 'Scan documents from WiFi printer — save as PDF or print',
            color: const Color(0xFF0EA5E9),
            badgeNum: '3',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const PrinterScanScreen())),
          ),
          const SizedBox(height: 12),

          // Coming soon
          _ModuleCard(
            icon: Icons.photo_size_select_large_outlined,
            title: 'Custom Print Sizes',
            description: 'Coming soon — wallets, 4x6, 5x7, 8x10 and more',
            color: AppTheme.textSecondary,
            badgeNum: null,
            locked: true,
            onTap: () {},
          ),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: const Text(
        'Photo Print Studio v1.0  •  3 Modules Active',
        style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
        textAlign: TextAlign.center,
      ),
    );
  }
}

class _ModuleCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final Color color;
  final String? badgeNum;
  final bool locked;
  final VoidCallback onTap;

  const _ModuleCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.color,
    required this.badgeNum,
    this.locked = false,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: locked ? AppTheme.surface : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: locked ? AppTheme.border : color.withOpacity(0.3),
            width: locked ? 1 : 1.5,
          ),
          boxShadow: locked
              ? []
              : [
                  BoxShadow(
                    color: color.withOpacity(0.08),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  )
                ],
        ),
        child: Row(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: locked ? AppTheme.border : color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(icon,
                      color: locked ? AppTheme.textSecondary : color,
                      size: 26),
                ),
                if (badgeNum != null)
                  Positioned(
                    top: -6,
                    right: -6,
                    child: Container(
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        color: color,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2),
                      ),
                      child: Center(
                        child: Text(
                          badgeNum!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          title,
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: locked
                                ? AppTheme.textSecondary
                                : AppTheme.textPrimary,
                          ),
                        ),
                      ),
                      if (locked)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: AppTheme.border,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Text('SOON',
                              style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  color: AppTheme.textSecondary)),
                        ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description,
                    style: const TextStyle(
                        fontSize: 13, color: AppTheme.textSecondary),
                  ),
                ],
              ),
            ),
            if (!locked)
              Icon(Icons.arrow_forward_ios,
                  size: 14, color: color.withOpacity(0.5)),
          ],
        ),
      ),
    );
  }
}

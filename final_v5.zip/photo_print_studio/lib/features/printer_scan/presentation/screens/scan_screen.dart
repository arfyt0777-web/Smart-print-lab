import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../shared/widgets/loading_overlay.dart';
import '../../data/printer_scan_models.dart';
import '../../data/printer_discovery_service.dart';
import '../../data/scan_pdf_service.dart';

class ScanScreen extends StatefulWidget {
  final PrinterDevice printer;
  const ScanScreen({super.key, required this.printer});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  static const moduleColor = Color(0xFF0EA5E9);

  final List<ScannedPage> _pages = [];
  bool _isScanning = false;
  bool _isExporting = false;
  String _loadingMsg = 'Scanning…';
  String _selectedColorMode = 'RGB24';
  int _selectedDpi = 300;
  bool _autoEnhance = true;

  late final ScanService _scanService;

  @override
  void initState() {
    super.initState();
    _scanService = ScanService(widget.printer);
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: _isScanning || _isExporting,
      message: _loadingMsg,
      child: Scaffold(
        backgroundColor: AppTheme.surface,
        appBar: AppBar(
          title: Text('Scan — ${widget.printer.name}'),
          leading: const BackButton(),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildPrinterInfo(),
                const SizedBox(height: 20),
                _buildScanSettings(),
                const SizedBox(height: 20),
                _buildScanButton(),
                const SizedBox(height: 20),
                if (_pages.isNotEmpty) ...[
                  _buildPageList(),
                  const SizedBox(height: 20),
                  _buildExportSection(),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPrinterInfo() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: moduleColor.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: moduleColor.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          const Icon(Icons.check_circle, color: AppTheme.success, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              '${widget.printer.name}  •  ${widget.printer.address}',
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScanSettings() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Scan Settings',
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary)),
          const SizedBox(height: 14),

          // Color mode
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Color Mode',
                  style: TextStyle(
                      fontSize: 13, color: AppTheme.textSecondary)),
              DropdownButton<String>(
                value: _selectedColorMode,
                underline: const SizedBox(),
                style: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.w600),
                items: const [
                  DropdownMenuItem(value: 'RGB24', child: Text('Color')),
                  DropdownMenuItem(
                      value: 'Grayscale8', child: Text('Grayscale')),
                  DropdownMenuItem(
                      value: 'BlackAndWhite1',
                      child: Text('Black & White')),
                ],
                onChanged: (v) =>
                    setState(() => _selectedColorMode = v ?? 'RGB24'),
              ),
            ],
          ),
          const Divider(height: 20),

          // Resolution
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Resolution',
                  style: TextStyle(
                      fontSize: 13, color: AppTheme.textSecondary)),
              DropdownButton<int>(
                value: _selectedDpi,
                underline: const SizedBox(),
                style: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.w600),
                items: const [
                  DropdownMenuItem(value: 150, child: Text('150 DPI')),
                  DropdownMenuItem(value: 300, child: Text('300 DPI')),
                  DropdownMenuItem(value: 600, child: Text('600 DPI')),
                ],
                onChanged: (v) =>
                    setState(() => _selectedDpi = v ?? 300),
              ),
            ],
          ),
          const Divider(height: 20),

          // Auto enhance
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Auto Enhance',
                      style: TextStyle(
                          fontSize: 13, color: AppTheme.textSecondary)),
                  Text('Sharpen & contrast for documents',
                      style: TextStyle(
                          fontSize: 11, color: AppTheme.textSecondary)),
                ],
              ),
              Switch(
                value: _autoEnhance,
                activeColor: moduleColor,
                onChanged: (v) => setState(() => _autoEnhance = v),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildScanButton() {
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _scanPage,
            icon: const Icon(Icons.document_scanner_outlined),
            label: Text(_pages.isEmpty ? 'Scan Page' : 'Scan Next Page'),
            style: ElevatedButton.styleFrom(
              backgroundColor: moduleColor,
              padding: const EdgeInsets.symmetric(vertical: 16),
              textStyle: const TextStyle(
                  fontSize: 15, fontWeight: FontWeight.w700),
            ),
          ),
        ),
        if (_pages.isNotEmpty) ...[
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => setState(() => _pages.clear()),
              icon: const Icon(Icons.delete_outline, size: 18),
              label: const Text('Clear All Pages'),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.error,
                side: const BorderSide(color: AppTheme.error),
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildPageList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Scanned Pages (${_pages.length})',
          style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 180,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: _pages.length,
            itemBuilder: (context, index) {
              final page = _pages[index];
              return Container(
                margin: const EdgeInsets.only(right: 12),
                width: 130,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppTheme.border),
                  color: Colors.white,
                ),
                child: Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(9),
                      child: Image.memory(
                        page.imageBytes,
                        width: 130,
                        height: 180,
                        fit: BoxFit.cover,
                      ),
                    ),
                    // Page number badge
                    Positioned(
                      bottom: 6,
                      left: 6,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.6),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          'Page ${page.pageNumber}',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                    // Delete button
                    Positioned(
                      top: 4,
                      right: 4,
                      child: GestureDetector(
                        onTap: () =>
                            setState(() => _pages.removeAt(index)),
                        child: Container(
                          width: 22,
                          height: 22,
                          decoration: const BoxDecoration(
                              color: AppTheme.error,
                              shape: BoxShape.circle),
                          child: const Icon(Icons.close,
                              color: Colors.white, size: 14),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildExportSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Export',
            style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimary)),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _ExportBtn(
                icon: Icons.picture_as_pdf_outlined,
                label: 'Save PDF',
                sublabel: '${_pages.length} page(s)',
                color: AppTheme.error,
                onTap: _savePdf,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _ExportBtn(
                icon: Icons.print_outlined,
                label: 'Print',
                sublabel: 'WiFi / BT',
                color: AppTheme.primary,
                onTap: _printPages,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: _ExportBtn(
            icon: Icons.save_alt_outlined,
            label: 'Save Images to Gallery',
            sublabel: 'High quality JPG — ${_pages.length} page(s)',
            color: AppTheme.success,
            onTap: _saveToGallery,
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  // ── Actions ──────────────────────────────────────────────────────────

  Future<void> _scanPage() async {
    setState(() { _isScanning = true; _loadingMsg = 'Scanning page ${_pages.length + 1}…'; });
    try {
      Uint8List bytes = await _scanService.scanPage(
        colorMode: _selectedColorMode,
        resolutionDpi: _selectedDpi,
      );

      if (_autoEnhance) {
        setState(() => _loadingMsg = 'Enhancing image…');
        bytes = ScanPdfService.enhanceScan(bytes);
      }

      final page = ScannedPage(
        imageBytes: bytes,
        pageNumber: _pages.length + 1,
        scannedAt: DateTime.now(),
      );

      if (mounted) {
        setState(() => _pages.add(page));
        _showSnack('✅  Page ${page.pageNumber} scanned!');
      }
    } catch (e) {
      if (mounted) _showSnack('Scan failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isScanning = false);
    }
  }

  Future<void> _savePdf() async {
    if (_pages.isEmpty) return;
    setState(() { _isExporting = true; _loadingMsg = 'Generating PDF…'; });
    try {
      final file = await ScanPdfService.generatePdf(
        _pages,
        fileName: 'scan_${DateTime.now().day}-${DateTime.now().month}',
        dpi: _selectedDpi,
      );
      await Printing.sharePdf(
        bytes: await file.readAsBytes(),
        filename: file.path.split('/').last,
      );
    } catch (e) {
      if (mounted) _showSnack('PDF failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _printPages() async {
    if (_pages.isEmpty) return;
    setState(() { _isExporting = true; _loadingMsg = 'Preparing print…'; });
    try {
      final file = await ScanPdfService.generatePdf(_pages, dpi: _selectedDpi);
      await Printing.layoutPdf(
        onLayout: (_) async => await file.readAsBytes(),
        name: 'Scanned Document',
      );
    } catch (e) {
      if (mounted) _showSnack('Print failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _saveToGallery() async {
    if (_pages.isEmpty) return;
    setState(() { _isExporting = true; _loadingMsg = 'Saving to gallery…'; });
    try {
      int saved = 0;
      final dir = await getTemporaryDirectory();
      for (final page in _pages) {
        final file = File(
            '${dir.path}/scan_p${page.pageNumber}_${DateTime.now().millisecondsSinceEpoch}.jpg');
        await file.writeAsBytes(page.imageBytes);
        await Gal.putImage(file.path, album: 'Photo Print Studio');
        saved++;
      }
      if (mounted) _showSnack('✅  $saved page(s) saved to gallery!');
    } catch (e) {
      if (mounted) _showSnack('Save failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? AppTheme.error : AppTheme.success,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }
}

class _ExportBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final String sublabel;
  final Color color;
  final VoidCallback onTap;
  const _ExportBtn(
      {required this.icon,
      required this.label,
      required this.sublabel,
      required this.color,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding:
            const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.06),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.25), width: 1.5),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: color)),
                Text(sublabel,
                    style: const TextStyle(
                        fontSize: 11, color: AppTheme.textSecondary)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

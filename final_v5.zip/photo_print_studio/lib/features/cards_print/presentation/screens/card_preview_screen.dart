import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../shared/widgets/loading_overlay.dart';
import '../../data/card_type_model.dart';
import '../../data/card_processing_service.dart';
import '../../data/card_pdf_export_service.dart';

class CardPreviewScreen extends StatefulWidget {
  final List<Uint8List> cardImages;
  final CardTypeModel cardType;

  const CardPreviewScreen({
    super.key,
    required this.cardImages,
    required this.cardType,
  });

  @override
  State<CardPreviewScreen> createState() => _CardPreviewScreenState();
}

class _CardPreviewScreenState extends State<CardPreviewScreen> {
  Uint8List? _sheetPng;
  bool _isGenerating = true;
  bool _isExporting = false;
  String _loadingMsg = 'Generating sheet…';

  @override
  void initState() {
    super.initState();
    _generateSheet();
  }

  Future<void> _generateSheet() async {
    setState(() {
      _isGenerating = true;
      _loadingMsg = 'Generating print sheet…';
    });
    try {
      final sheet = await CardProcessingService.generateCardSheet(
          widget.cardImages, widget.cardType);
      if (mounted) setState(() { _sheetPng = sheet; _isGenerating = false; });
    } catch (e) {
      if (mounted) {
        setState(() => _isGenerating = false);
        _showSnack('Sheet generation failed: $e', isError: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: _isGenerating || _isExporting,
      message: _loadingMsg,
      child: Scaffold(
        backgroundColor: AppTheme.surface,
        appBar: AppBar(
          title: Text('${widget.cardType.name} Sheet'),
          leading: const BackButton(),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSheetInfo(),
                const SizedBox(height: 16),
                _buildSheetPreview(),
                const SizedBox(height: 24),
                _buildExportSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSheetInfo() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: widget.cardType.color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: widget.cardType.color.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Icon(widget.cardType.icon, color: widget.cardType.color, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              '${widget.cardImages.length} × ${widget.cardType.name}  •  2 per row  •  4×6 inch sheet  •  300 DPI',
              style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSheetPreview() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Sheet Preview',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary),
            ),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppTheme.success.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text('4×6 inch',
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.success)),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.grey[200],
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.border),
          ),
          child: AspectRatio(
            aspectRatio: 4 / 6,
            child: _sheetPng != null
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: Image.memory(_sheetPng!, fit: BoxFit.cover),
                  )
                : const Center(
                    child: CircularProgressIndicator(color: AppTheme.primary)),
          ),
        ),
      ],
    );
  }

  Widget _buildExportSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Export & Print',
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _ExportButton(
                icon: Icons.save_alt_outlined,
                label: 'Save to Gallery',
                sublabel: 'High-quality JPG',
                color: AppTheme.success,
                onTap: _saveToGallery,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _ExportButton(
                icon: Icons.print_outlined,
                label: 'Print',
                sublabel: 'WiFi / Bluetooth',
                color: AppTheme.primary,
                onTap: _printSheet,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: _ExportButton(
            icon: Icons.picture_as_pdf_outlined,
            label: 'Download as PDF',
            sublabel: 'Print-ready 4×6 PDF',
            color: AppTheme.error,
            onTap: _downloadAsPdf,
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  // ── Export ───────────────────────────────────────────────────────────

  Future<void> _saveToGallery() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMsg = 'Saving to gallery…'; });
    try {
      final dir = await getTemporaryDirectory();
      final file = File(
          '${dir.path}/cards_sheet_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await file.writeAsBytes(_sheetPng!);
      await Gal.putImage(file.path, album: 'Photo Print Studio');
      if (mounted) _showSnack('✅  Saved to gallery!');
    } catch (e) {
      if (mounted) _showSnack('Save failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _printSheet() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMsg = 'Preparing print…'; });
    try {
      final pdf = await CardPdfExportService.generatePdf(_sheetPng!);
      final pdfBytes = await pdf.readAsBytes();
      await Printing.layoutPdf(
        onLayout: (_) async => pdfBytes,
        name: '${widget.cardType.name} Sheet',
      );
    } catch (e) {
      if (mounted) _showSnack('Print failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _downloadAsPdf() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMsg = 'Generating PDF…'; });
    try {
      final pdf = await CardPdfExportService.generatePdf(_sheetPng!);
      await Printing.sharePdf(
        bytes: await pdf.readAsBytes(),
        filename: '${widget.cardType.name.toLowerCase().replaceAll(' ', '_')}_sheet.pdf',
      );
    } catch (e) {
      if (mounted) _showSnack('PDF export failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? AppTheme.error : AppTheme.success,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }
}

class _ExportButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final String sublabel;
  final Color color;
  final VoidCallback onTap;

  const _ExportButton({
    required this.icon,
    required this.label,
    required this.sublabel,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.25), width: 1.5),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: color)),
                Text(sublabel,
                    style: const TextStyle(
                        fontSize: 11, color: AppTheme.textSecondary)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

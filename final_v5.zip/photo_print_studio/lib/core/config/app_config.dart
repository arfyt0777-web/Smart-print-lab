/// ============================================================
///  CONFIGURATION FILE
///  Put your Groq API key here before building the APK.
/// ============================================================

class AppConfig {
  // ----------------------------------------------------------
  // 🔑  GROQ API KEY — replace the placeholder below
  // ----------------------------------------------------------
  static const String groqApiKey = 'YOUR_GROQ_API_KEY_HERE';

  // Groq endpoint used for vision-based background removal
  static const String groqBaseUrl = 'https://api.groq.com/openai/v1';

  // Model used for background-removal prompt
  static const String groqVisionModel = 'meta-llama/llama-4-scout-17b-16e-instruct';

  // ----------------------------------------------------------
  // App-level constants
  // ----------------------------------------------------------
  static const String appName = 'Photo Print Studio';
  static const String appVersion = '1.0.0';

  // Passport photo dimensions (pixels at 300 DPI)
  // Standard: 35 mm × 45 mm  →  413 × 531 px @ 300 dpi
  static const int passportWidthPx  = 413;
  static const int passportHeightPx = 531;

  // Print sheet: 4 × 6 inches @ 300 DPI
  static const int sheetWidthPx  = 1200;
  static const int sheetHeightPx = 1800;

  // Spacing between photos on sheet (px)
  static const int photoSpacingPx = 20;
  static const int sheetPaddingPx = 30;
}

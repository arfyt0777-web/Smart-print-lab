# Flutter
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }

# Printing / PDF
-keep class com.github.barteksc.** { *; }

# image_picker / camera
-keep class androidx.core.content.FileProvider { *; }

# Groq / HTTP
-dontwarn okhttp3.**
-dontwarn okio.**

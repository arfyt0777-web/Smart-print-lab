import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import '../../../core/config/app_config.dart';

/// Generates a 4×6 inch print sheet (1200×1800 px at 300 DPI)
/// with the requested number of passport photos arranged on it.
class SheetGeneratorService {
  /// [subjectPng]   – PNG bytes with transparent background (RGBA)
  /// [bgColor]      – background colour to fill behind the subject
  /// [photoCount]   – 2, 4, 6, 8, 10, or 12
  ///
  /// Returns PNG bytes of the finished print sheet.
  static Future<Uint8List> generateSheet({
    required Uint8List subjectPng,
    required Color bgColor,
    required int photoCount,
  }) async {
    // Decode the transparent subject
    img.Image? subject = img.decodeImage(subjectPng);
    if (subject == null) throw Exception('Could not decode subject image');

    // Convert to RGBA
    subject = subject.convert(numChannels: 4);

    // ── 1. Compose a single passport photo ───────────────────────────
    final passportPhoto = _composeSinglePhoto(subject, bgColor);

    // Resize to standard passport dimensions (413×531 @ 300dpi)
    final resized = img.copyResize(
      passportPhoto,
      width: AppConfig.passportWidthPx,
      height: AppConfig.passportHeightPx,
      interpolation: img.Interpolation.cubic,
    );

    // ── 2. Figure out grid layout ────────────────────────────────────
    final layout = _computeLayout(photoCount);

    // ── 3. Create the sheet canvas (white background) ────────────────
    final sheet = img.Image(
      width: AppConfig.sheetWidthPx,
      height: AppConfig.sheetHeightPx,
      numChannels: 3,
    );
    img.fill(sheet, color: img.ColorRgb8(255, 255, 255));

    // ── 4. Stamp photos on the sheet ─────────────────────────────────
    final padding = AppConfig.sheetPaddingPx;
    final spacing = AppConfig.photoSpacingPx;

    final cols = layout[0];
    final rows = layout[1];

    // Centre the grid on the sheet
    final totalW = cols * AppConfig.passportWidthPx  + (cols - 1) * spacing;
    final totalH = rows * AppConfig.passportHeightPx + (rows - 1) * spacing;
    final startX = ((AppConfig.sheetWidthPx  - totalW) / 2).round();
    final startY = ((AppConfig.sheetHeightPx - totalH) / 2).round();

    int count = 0;
    for (int row = 0; row < rows && count < photoCount; row++) {
      for (int col = 0; col < cols && count < photoCount; col++) {
        final x = startX + col * (AppConfig.passportWidthPx  + spacing);
        final y = startY + row * (AppConfig.passportHeightPx + spacing);
        img.compositeImage(sheet, resized, dstX: x, dstY: y);
        count++;
      }
    }

    return Uint8List.fromList(img.encodePng(sheet));
  }

  /// Fills the transparent background with [bgColor] and returns RGB image.
  static img.Image _composeSinglePhoto(img.Image subject, Color bgColor) {
    final result = img.Image(
      width: subject.width,
      height: subject.height,
      numChannels: 3,
    );

    final r = bgColor.red;
    final g = bgColor.green;
    final b = bgColor.blue;

    for (int y = 0; y < subject.height; y++) {
      for (int x = 0; x < subject.width; x++) {
        final p = subject.getPixel(x, y);
        final alpha = p.a / 255.0;

        final fr = (p.r * alpha + r * (1 - alpha)).round().clamp(0, 255);
        final fg = (p.g * alpha + g * (1 - alpha)).round().clamp(0, 255);
        final fb = (p.b * alpha + b * (1 - alpha)).round().clamp(0, 255);

        result.setPixel(x, y, img.ColorRgb8(fr, fg, fb));
      }
    }
    return result;
  }

  /// Returns [cols, rows] that fits [photoCount] on a 4×6 sheet.
  static List<int> _computeLayout(int photoCount) {
    switch (photoCount) {
      case 2:  return [2, 1];
      case 4:  return [2, 2];
      case 6:  return [3, 2];
      case 8:  return [4, 2];
      case 10: return [5, 2];
      case 12: return [4, 3];
      default: return [2, 2];
    }
  }
}

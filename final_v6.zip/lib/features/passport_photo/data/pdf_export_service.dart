import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'dart:io';

/// Wraps the print-sheet image in a 4×6 inch PDF ready for printing.
class PdfExportService {
  /// [sheetPngBytes] – PNG bytes of the generated sheet (1200×1800 px)
  ///
  /// Returns the PDF file.
  static Future<File> generatePdf(Uint8List sheetPngBytes) async {
    final pdf = pw.Document(
      version: PdfVersion.pdf_1_5,
      compress: true,
    );

    final image = pw.MemoryImage(sheetPngBytes);

    // 4×6 inch page
    const pageFormat = PdfPageFormat(
      4 * PdfPageFormat.inch,
      6 * PdfPageFormat.inch,
      marginAll: 0,
    );

    pdf.addPage(
      pw.Page(
        pageFormat: pageFormat,
        margin: pw.EdgeInsets.zero,
        build: (context) => pw.Image(image, fit: pw.BoxFit.fill),
      ),
    );

    final dir  = await getTemporaryDirectory();
    final file = File('${dir.path}/passport_sheet_${DateTime.now().millisecondsSinceEpoch}.pdf');
    await file.writeAsBytes(await pdf.save());
    return file;
  }
}

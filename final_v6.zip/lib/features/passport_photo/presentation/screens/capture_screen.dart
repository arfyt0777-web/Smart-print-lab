import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../shared/widgets/loading_overlay.dart';
import 'background_screen.dart';

class CaptureScreen extends StatefulWidget {
  const CaptureScreen({super.key});

  @override
  State<CaptureScreen> createState() => _CaptureScreenState();
}

class _CaptureScreenState extends State<CaptureScreen> {
  final _picker = ImagePicker();
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: _isLoading,
      message: 'Preparing image...',
      child: Scaffold(
        backgroundColor: AppTheme.surface,
        appBar: AppBar(title: const Text('Passport Photo Maker')),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const SizedBox(height: 16),
                _buildHero(),
                const SizedBox(height: 32),
                _buildTitle(),
                const SizedBox(height: 40),
                _buildButtons(),
                const Spacer(),
                _buildTips(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHero() {
    return Container(
      width: 140, height: 140,
      decoration: BoxDecoration(
        color: AppTheme.primary.withOpacity(0.08),
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Container(
          width: 100, height: 100,
          decoration: BoxDecoration(
            color: AppTheme.primary.withOpacity(0.12),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.face_outlined, size: 56, color: AppTheme.primary),
        ),
      ),
    );
  }

  Widget _buildTitle() {
    return const Column(
      children: [
        Text('Add Your Photo',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: AppTheme.textPrimary)),
        SizedBox(height: 8),
        Text('Take a new photo or choose from gallery.\nAI will remove background automatically.',
            style: TextStyle(fontSize: 14, color: AppTheme.textSecondary, height: 1.5),
            textAlign: TextAlign.center),
      ],
    );
  }

  Widget _buildButtons() {
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _captureFromCamera,
            icon: const Icon(Icons.camera_alt_outlined),
            label: const Text('Take a Photo'),
            style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: _pickFromGallery,
            icon: const Icon(Icons.photo_library_outlined),
            label: const Text('Choose from Gallery'),
            style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
          ),
        ),
      ],
    );
  }

  Widget _buildTips() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.primary.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.primary.withOpacity(0.15)),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Tips for best results',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppTheme.primary)),
          SizedBox(height: 8),
          Text('📸  Face the camera directly', style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
          SizedBox(height: 4),
          Text('💡  Use good, even lighting', style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
          SizedBox(height: 4),
          Text('⚪  Plain background works best', style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
        ],
      ),
    );
  }

  Future<void> _captureFromCamera() async {
    setState(() => _isLoading = true);
    try {
      final xFile = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 100,
        preferredCameraDevice: CameraDevice.front,
      );
      if (xFile == null) {
        setState(() => _isLoading = false);
        return;
      }
      final file = File(xFile.path);
      if (!mounted) return;
      setState(() => _isLoading = false);
      Navigator.push(context,
          MaterialPageRoute(builder: (_) => BackgroundScreen(imageFile: file)));
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Camera error: $e'), backgroundColor: AppTheme.error),
        );
      }
    }
  }

  Future<void> _pickFromGallery() async {
    setState(() => _isLoading = true);
    try {
      final xFile = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 100,
      );
      if (xFile == null) {
        setState(() => _isLoading = false);
        return;
      }
      final file = File(xFile.path);
      if (!mounted) return;
      setState(() => _isLoading = false);
      Navigator.push(context,
          MaterialPageRoute(builder: (_) => BackgroundScreen(imageFile: file)));
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gallery error: $e'), backgroundColor: AppTheme.error),
        );
      }
    }
  }
}

import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'printer_scan_models.dart';

class ScanPdfService {
  /// Combines multiple scanned pages into a single high-quality PDF.
  /// Each page is sized to match the original scan dimensions.
  static Future<File> generatePdf(
    List<ScannedPage> pages, {
    String fileName = 'scan',
    int dpi = 300,
  }) async {
    final pdf = pw.Document(
      version: PdfVersion.pdf_1_5,
      compress: false, // no compression to preserve quality
    );

    for (final page in pages) {
      // Decode to get dimensions
      final decoded = img.decodeImage(page.imageBytes);
      if (decoded == null) continue;

      // Convert pixels to points (1 inch = 72 points, at given DPI)
      final widthPt  = decoded.width  / dpi * 72.0;
      final heightPt = decoded.height / dpi * 72.0;

      final pdfImage = pw.MemoryImage(page.imageBytes);
      final pageFormat = PdfPageFormat(widthPt, heightPt, marginAll: 0);

      pdf.addPage(
        pw.Page(
          pageFormat: pageFormat,
          margin: pw.EdgeInsets.zero,
          build: (_) => pw.Image(pdfImage, fit: pw.BoxFit.fill),
        ),
      );
    }

    final dir = await getTemporaryDirectory();
    final ts  = DateTime.now().millisecondsSinceEpoch;
    final file = File('${dir.path}/${fileName}_$ts.pdf');
    await file.writeAsBytes(await pdf.save());
    return file;
  }

  /// Enhance scanned image: denoise + sharpen for documents.
  static Uint8List enhanceScan(Uint8List bytes) {
    img.Image? src = img.decodeImage(bytes);
    if (src == null) return bytes;

    // Auto levels + slight sharpening for text clarity
    src = img.adjustColor(src, contrast: 1.15, brightness: 1.02);
    src = img.convolution(src, filter: [
      0, -0.5, 0,
      -0.5, 3, -0.5,
      0, -0.5, 0,
    ], div: 1, offset: 0);

    return Uint8List.fromList(img.encodeJpg(src, quality: 100));
  }
}

import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'printer_scan_models.dart';

class PrinterDiscoveryService {
  static const _ippPort = 631;

  static Future<List<PrinterDevice>> discoverPrinters() async {
    final printers = <PrinterDevice>[];
    try {
      final wifiPrinters = await _scanNetworkForPrinters();
      printers.addAll(wifiPrinters);
    } catch (_) {}
    return printers;
  }

  static Future<List<PrinterDevice>> _scanNetworkForPrinters() async {
    final found = <PrinterDevice>[];
    String subnet = '192.168.1';

    try {
      for (final iface in await NetworkInterface.list()) {
        for (final addr in iface.addresses) {
          if (!addr.isLoopback && addr.type == InternetAddressType.IPv4) {
            final parts = addr.address.split('.');
            if (parts.length == 4) {
              subnet = '${parts[0]}.${parts[1]}.${parts[2]}';
            }
          }
        }
      }
    } catch (_) {}

    final futures = <Future>[];
    for (int i = 1; i <= 254; i++) {
      final ip = '$subnet.$i';
      futures.add(_checkIpp(ip).then((device) {
        if (device != null) found.add(device);
      }));
      if (futures.length >= 20) {
        await Future.wait(futures);
        futures.clear();
      }
    }
    if (futures.isNotEmpty) await Future.wait(futures);
    return found;
  }

  static Future<PrinterDevice?> _checkIpp(String ip) async {
    try {
      final socket = await Socket.connect(
        ip, _ippPort,
        timeout: const Duration(milliseconds: 400),
      );
      await socket.close();
      return PrinterDevice(
        id: 'wifi_$ip',
        name: 'Network Printer ($ip)',
        address: ip,
        type: PrinterConnectionType.wifi,
        status: PrinterStatus.disconnected,
      );
    } catch (_) {
      return null;
    }
  }
}

class ScanService {
  final PrinterDevice printer;
  ScanService(this.printer);

  Future<Uint8List> scanPage({
    String colorMode = 'RGB24',
    int resolutionDpi = 300,
    String format = 'image/jpeg',
  }) async {
    final baseUrl = 'http://${printer.address}';

    final scanSettings = '''<?xml version="1.0" encoding="UTF-8"?>
<scan:ScanSettings xmlns:scan="http://schemas.hp.com/imaging/escl/2011/05/03"
                   xmlns:pwg="http://www.pwg.org/schemas/2010/12/sm">
  <pwg:Version>2.6</pwg:Version>
  <scan:Intent>TextAndGraphic</scan:Intent>
  <pwg:ScanRegions>
    <pwg:ScanRegion>
      <pwg:ContentRegionUnits>escl:ThreeHundredthsOfInches</pwg:ContentRegionUnits>
      <pwg:Height>4200</pwg:Height>
      <pwg:Width>3300</pwg:Width>
      <pwg:XOffset>0</pwg:XOffset>
      <pwg:YOffset>0</pwg:YOffset>
    </pwg:ScanRegion>
  </pwg:ScanRegions>
  <pwg:DocumentFormat>$format</pwg:DocumentFormat>
  <scan:ColorMode>$colorMode</scan:ColorMode>
  <scan:XResolution>$resolutionDpi</scan:XResolution>
  <scan:YResolution>$resolutionDpi</scan:YResolution>
</scan:ScanSettings>''';

    final createResponse = await HttpClient()
        .postUrl(Uri.parse('$baseUrl/eSCL/ScanJobs'))
        .then((req) {
      req.headers.contentType =
          ContentType('application', 'xml', charset: 'utf-8');
      req.write(scanSettings);
      return req.close();
    });

    if (createResponse.statusCode != 201) {
      throw Exception('Scan job creation failed: ${createResponse.statusCode}');
    }

    final jobLocation = createResponse.headers.value('location');
    if (jobLocation == null) throw Exception('No scan job location returned');

    await Future.delayed(const Duration(seconds: 2));

    final imageUrl = '$jobLocation/NextDocument';
    final imageResponse = await HttpClient()
        .getUrl(Uri.parse(imageUrl))
        .then((req) => req.close());

    if (imageResponse.statusCode != 200) {
      throw Exception('Failed to retrieve scan: ${imageResponse.statusCode}');
    }

    final bytes = <int>[];
    await for (final chunk in imageResponse) {
      bytes.addAll(chunk);
    }

    return Uint8List.fromList(bytes);
  }
}

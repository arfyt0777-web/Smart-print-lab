import 'dart:typed_data';

enum PrinterConnectionType { wifi, bluetooth, usb }

enum PrinterStatus { connected, disconnected, connecting, error }

class PrinterDevice {
  final String id;
  final String name;
  final String address;
  final PrinterConnectionType type;
  PrinterStatus status;

  PrinterDevice({
    required this.id,
    required this.name,
    required this.address,
    required this.type,
    this.status = PrinterStatus.disconnected,
  });

  String get statusLabel {
    switch (status) {
      case PrinterStatus.connected:    return 'Connected';
      case PrinterStatus.disconnected: return 'Available';
      case PrinterStatus.connecting:   return 'Connecting…';
      case PrinterStatus.error:        return 'Error';
    }
  }

  String get typeLabel {
    switch (type) {
      case PrinterConnectionType.wifi:      return 'WiFi';
      case PrinterConnectionType.bluetooth: return 'Bluetooth';
      case PrinterConnectionType.usb:       return 'USB';
    }
  }
}

class ScannedPage {
  final Uint8List imageBytes;
  final int pageNumber;
  final DateTime scannedAt;

  const ScannedPage({
    required this.imageBytes,
    required this.pageNumber,
    required this.scannedAt,
  });
}

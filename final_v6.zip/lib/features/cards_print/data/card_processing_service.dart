import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'card_type_model.dart';

class CardProcessingService {
  // Sheet: 4x6 inch @ 300 DPI
  static const int sheetW = 1200;
  static const int sheetH = 1800;
  static const int sheetPadding = 40;
  static const int cardSpacing = 30;

  /// Auto-crop card from image using edge detection.
  /// Returns JPEG bytes of the cropped card at original quality.
  static Future<Uint8List> cropCard(File imageFile) async {
    final bytes = await imageFile.readAsBytes();
    img.Image? original = img.decodeImage(bytes);
    if (original == null) throw Exception('Cannot decode image');

    // Auto-detect card region via edge/contrast analysis
    final cropped = _autoCropCard(original);

    // Auto-enhance: adjust brightness + contrast
    final enhanced = _enhanceCard(cropped);

    return Uint8List.fromList(img.encodeJpg(enhanced, quality: 100));
  }

  /// Crop card from PDF page image bytes (already rasterized).
  static Future<Uint8List> cropCardFromBytes(Uint8List bytes) async {
    img.Image? original = img.decodeImage(bytes);
    if (original == null) throw Exception('Cannot decode image');
    final cropped = _autoCropCard(original);
    final enhanced = _enhanceCard(cropped);
    return Uint8List.fromList(img.encodeJpg(enhanced, quality: 100));
  }

  /// Generate a 4x6 print sheet with all card images.
  /// Cards arranged 2 per row.
  static Future<Uint8List> generateCardSheet(
      List<Uint8List> cardImages, CardTypeModel cardType) async {
    // White sheet
    final sheet = img.Image(width: sheetW, height: sheetH, numChannels: 3);
    img.fill(sheet, color: img.ColorRgb8(255, 255, 255));

    // Card dimensions on sheet
    final cardW = cardType.widthPx;
    final cardH = cardType.heightPx;

    // 2 cards per row
    const cols = 2;
    final rows = (cardImages.length / cols).ceil();

    // Calculate total grid size and center it
    final totalW = cols * cardW + (cols - 1) * cardSpacing;
    final totalH = rows * cardH + (rows - 1) * cardSpacing;
    final startX = ((sheetW - totalW) / 2).round();
    final startY = ((sheetH - totalH) / 2).round();

    for (int i = 0; i < cardImages.length; i++) {
      final col = i % cols;
      final row = i ~/ cols;

      img.Image? cardImg = img.decodeImage(cardImages[i]);
      if (cardImg == null) continue;

      // Resize card to standard size maintaining aspect ratio
      final resized = img.copyResize(
        cardImg,
        width: cardW,
        height: cardH,
        interpolation: img.Interpolation.cubic,
      );

      final x = startX + col * (cardW + cardSpacing);
      final y = startY + row * (cardH + cardSpacing);

      // Draw thin border around each card
      _drawCardBorder(sheet, x - 1, y - 1, cardW + 2, cardH + 2);

      img.compositeImage(sheet, resized, dstX: x, dstY: y);
    }

    return Uint8List.fromList(img.encodePng(sheet));
  }

  // ── Private helpers ────────────────────────────────────────────────

  /// Auto-crop: finds the largest rectangular region with high contrast edges.
  static img.Image _autoCropCard(img.Image src) {
    final w = src.width;
    final h = src.height;

    // Convert to grayscale for edge detection
    final gray = img.grayscale(src);

    // Scan from edges inward to find content boundaries
    // Top boundary
    int top = 0;
    outer:
    for (int y = 0; y < h; y++) {
      for (int x = 0; x < w; x++) {
        final p = gray.getPixel(x, y);
        if (p.r < 240) {
          top = y;
          break outer;
        }
      }
    }

    // Bottom boundary
    int bottom = h - 1;
    outer:
    for (int y = h - 1; y >= 0; y--) {
      for (int x = 0; x < w; x++) {
        final p = gray.getPixel(x, y);
        if (p.r < 240) {
          bottom = y;
          break outer;
        }
      }
    }

    // Left boundary
    int left = 0;
    outer:
    for (int x = 0; x < w; x++) {
      for (int y = 0; y < h; y++) {
        final p = gray.getPixel(x, y);
        if (p.r < 240) {
          left = x;
          break outer;
        }
      }
    }

    // Right boundary
    int right = w - 1;
    outer:
    for (int x = w - 1; x >= 0; x--) {
      for (int y = 0; y < h; y++) {
        final p = gray.getPixel(x, y);
        if (p.r < 240) {
          right = x;
          break outer;
        }
      }
    }

    // Add small padding
    const pad = 8;
    top    = (top    - pad).clamp(0, h - 1);
    bottom = (bottom + pad).clamp(0, h - 1);
    left   = (left   - pad).clamp(0, w - 1);
    right  = (right  + pad).clamp(0, w - 1);

    final cropW = right - left;
    final cropH = bottom - top;

    if (cropW < 50 || cropH < 50) return src; // fallback: no crop

    return img.copyCrop(src, x: left, y: top, width: cropW, height: cropH);
  }

  /// Auto-enhance: slightly boost contrast and brightness.
  static img.Image _enhanceCard(img.Image src) {
    // Adjust levels: slight contrast boost
    return img.adjustColor(
      src,
      contrast: 1.1,
      brightness: 1.05,
      saturation: 1.05,
    );
  }

  /// Draw a light grey 1px border around a card.
  static void _drawCardBorder(
      img.Image sheet, int x, int y, int w, int h) {
    final borderColor = img.ColorRgb8(200, 200, 200);
    for (int i = x; i < x + w; i++) {
      if (i >= 0 && i < sheet.width) {
        if (y >= 0 && y < sheet.height) sheet.setPixel(i, y, borderColor);
        if (y + h - 1 >= 0 && y + h - 1 < sheet.height)
          sheet.setPixel(i, y + h - 1, borderColor);
      }
    }
    for (int j = y; j < y + h; j++) {
      if (j >= 0 && j < sheet.height) {
        if (x >= 0 && x < sheet.width) sheet.setPixel(x, j, borderColor);
        if (x + w - 1 >= 0 && x + w - 1 < sheet.width)
          sheet.setPixel(x + w - 1, j, borderColor);
      }
    }
  }
}

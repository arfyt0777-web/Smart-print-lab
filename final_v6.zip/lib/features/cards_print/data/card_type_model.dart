import 'package:flutter/material.dart';

enum CardType {
  aadhaar,
  pan,
  ration,
  other,
}

class CardTypeModel {
  final CardType type;
  final String name;
  final String description;
  final IconData icon;
  final Color color;
  // Standard card dimensions in mm (CR80 = 85.6 x 54 mm)
  final double widthMm;
  final double heightMm;

  const CardTypeModel({
    required this.type,
    required this.name,
    required this.description,
    required this.icon,
    required this.color,
    this.widthMm = 85.6,
    this.heightMm = 54.0,
  });

  // Width in px at 300 DPI
  int get widthPx => (widthMm / 25.4 * 300).round();
  // Height in px at 300 DPI
  int get heightPx => (heightMm / 25.4 * 300).round();

  static const List<CardTypeModel> all = [
    CardTypeModel(
      type: CardType.aadhaar,
      name: 'Aadhaar Card',
      description: 'UIDAI 12-digit identity card',
      icon: Icons.fingerprint,
      color: Color(0xFF1A56DB),
    ),
    CardTypeModel(
      type: CardType.pan,
      name: 'PAN Card',
      description: 'Income Tax permanent account number',
      icon: Icons.account_balance_outlined,
      color: Color(0xFFD97706),
    ),
    CardTypeModel(
      type: CardType.ration,
      name: 'Ration Card',
      description: 'Government food supply card',
      icon: Icons.kitchen_outlined,
      color: Color(0xFF059669),
    ),
    CardTypeModel(
      type: CardType.other,
      name: 'Other ID Card',
      description: 'Voter ID, Driving License, etc.',
      icon: Icons.badge_outlined,
      color: Color(0xFF7C3AED),
    ),
  ];
}

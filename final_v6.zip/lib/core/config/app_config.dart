class AppConfig {
  static const String groqApiKey = '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';
  static const String groqBaseUrl = 'https://api.groq.com/openai/v1';
  static const String groqVisionModel = 'meta-llama/llama-4-scout-17b-16e-instruct';
  static const String appName = 'SmartPrint';
  static const String appVersion = '1.0.0';
  static const int passportWidthPx  = 413;
  static const int passportHeightPx = 531;
  static const int sheetWidthPx  = 1200;
  static const int sheetHeightPx = 1800;
  static const int photoSpacingPx = 20;
  static const int sheetPaddingPx = 30;
}

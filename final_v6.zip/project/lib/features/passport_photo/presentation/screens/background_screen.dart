import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../shared/widgets/loading_overlay.dart';
import '../../data/background_removal_service.dart';
import 'sheet_screen.dart';

class BackgroundScreen extends StatefulWidget {
  final File imageFile;
  const BackgroundScreen({super.key, required this.imageFile});

  @override
  State<BackgroundScreen> createState() => _BackgroundScreenState();
}

class _BackgroundScreenState extends State<BackgroundScreen> {
  Uint8List? _processedPng; // transparent-bg PNG
  bool _isLoading = true;
  String _loadingMessage = 'Removing background with AI…';
  Color _selectedBg = Colors.white;
  String? _errorMessage;
  bool _showOriginal = false;

  final List<_BgOption> _bgOptions = [
    _BgOption('White',      Colors.white),
    _BgOption('St. Blue',   const Color(0xFF1A56DB)),
    _BgOption('St. Red',    const Color(0xFFDC2626)),
    _BgOption('St. Green',  const Color(0xFF16A34A)),
    _BgOption('St. Yellow', const Color(0xFFF59E0B)),
    _BgOption('St. Purple', const Color(0xFF7C3AED)),
  ];

  @override
  void initState() {
    super.initState();
    _removeBackground();
  }

  Future<void> _removeBackground() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _processedPng = null;
      _loadingMessage = 'Removing background with AI…';
    });
    try {
      final result = await BackgroundRemovalService.removeBackground(widget.imageFile);
      if (mounted) setState(() { _processedPng = result; _isLoading = false; });
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'Background removal failed:\n${e.toString()}';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: _isLoading,
      message: _loadingMessage,
      child: Scaffold(
        backgroundColor: AppTheme.surface,
        appBar: AppBar(
          title: const Text('Background Removal'),
          actions: [
            if (_processedPng != null)
              TextButton(
                onPressed: _proceedToSheet,
                child: const Text('Next →',
                    style: TextStyle(
                        fontWeight: FontWeight.w700, color: AppTheme.primary)),
              ),
          ],
        ),
        body: _errorMessage != null
            ? _buildError()
            : _processedPng == null
                ? const SizedBox.shrink()
                : _buildContent(),
      ),
    );
  }

  Widget _buildContent() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildPreview(),
            const SizedBox(height: 24),
            _buildBgSelector(),
            const SizedBox(height: 24),
            _buildNextButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildPreview() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Preview',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimary)),
        const SizedBox(height: 4),
        Text('Tap and hold to compare with original',
            style:
                const TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
        const SizedBox(height: 12),
        Center(
          child: GestureDetector(
            onLongPressStart: (_) => setState(() => _showOriginal = true),
            onLongPressEnd: (_)   => setState(() => _showOriginal = false),
            child: Stack(
              alignment: Alignment.topRight,
              children: [
                Container(
                  width: 240,
                  height: 308,
                  decoration: BoxDecoration(
                    color: _selectedBg,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppTheme.border),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.08),
                        blurRadius: 16,
                        offset: const Offset(0, 4),
                      )
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: _showOriginal
                        ? Image.file(widget.imageFile, fit: BoxFit.cover)
                        : Image.memory(_processedPng!, fit: BoxFit.contain),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.all(8),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    _showOriginal ? 'ORIGINAL' : 'PROCESSED',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBgSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Background Color',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimary)),
        const SizedBox(height: 12),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            ..._bgOptions.map((opt) => _ColorChip(
                  label: opt.label,
                  color: opt.color,
                  isSelected: _selectedBg == opt.color,
                  onTap: () => setState(() => _selectedBg = opt.color),
                )),
            // Custom colour picker
            GestureDetector(
              onTap: _showColorPicker,
              child: Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  border: Border.all(color: AppTheme.border, width: 2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.colorize, color: AppTheme.primary, size: 22),
                    SizedBox(height: 4),
                    Text('Custom',
                        style: TextStyle(
                            fontSize: 11, color: AppTheme.textSecondary)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildNextButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: _proceedToSheet,
        icon: const Icon(Icons.grid_view_outlined),
        label: const Text('Generate Print Sheet'),
        style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 16)),
      ),
    );
  }

  Widget _buildError() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 56, color: AppTheme.error),
            const SizedBox(height: 16),
            Text(_errorMessage!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: AppTheme.textPrimary)),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _removeBackground,
              icon: const Icon(Icons.refresh),
              label: const Text('Retry'),
            ),
          ],
        ),
      ),
    );
  }

  void _showColorPicker() {
    Color pickerColor = _selectedBg;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Pick a Color'),
        content: SingleChildScrollView(
          child: ColorPicker(
            pickerColor: pickerColor,
            onColorChanged: (c) => pickerColor = c,
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              setState(() => _selectedBg = pickerColor);
              Navigator.pop(context);
            },
            child: const Text('Select'),
          ),
        ],
      ),
    );
  }

  void _proceedToSheet() {
    if (_processedPng == null) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SheetScreen(
          processedPng: _processedPng!,
          bgColor: _selectedBg,
        ),
      ),
    );
  }
}

class _BgOption {
  final String label;
  final Color color;
  const _BgOption(this.label, this.color);
}

class _ColorChip extends StatelessWidget {
  final String label;
  final Color color;
  final bool isSelected;
  final VoidCallback onTap;

  const _ColorChip({
    required this.label,
    required this.color,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 72,
        height: 72,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? AppTheme.primary : AppTheme.border,
            width: isSelected ? 2.5 : 1.5,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: AppTheme.primary.withOpacity(0.25),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  )
                ]
              : [],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            if (isSelected)
              const Icon(Icons.check_circle, color: AppTheme.primary, size: 18),
            Padding(
              padding: const EdgeInsets.only(bottom: 6, top: 2),
              child: Text(label,
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: color.computeLuminance() > 0.5
                        ? AppTheme.textPrimary
                        : Colors.white,
                  )),
            ),
          ],
        ),
      ),
    );
  }
}

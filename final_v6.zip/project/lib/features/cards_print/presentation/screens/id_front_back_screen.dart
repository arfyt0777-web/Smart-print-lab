import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image/image.dart' as img;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../shared/widgets/loading_overlay.dart';
import '../../../../shared/utils/image_compress_util.dart';

/// ID Card Front + Back sheet:
/// One A4 sheet with FRONT on top half, BACK on bottom half.
/// No duplicates. Aspect ratio always preserved.
class IdFrontBackScreen extends StatefulWidget {
  const IdFrontBackScreen({super.key});
  @override
  State<IdFrontBackScreen> createState() => _IdFrontBackScreenState();
}

class _IdFrontBackScreenState extends State<IdFrontBackScreen> {
  final _picker = ImagePicker();
  File? _frontFile;
  File? _backFile;
  Uint8List? _sheetPng;
  bool _isLoading = false;
  bool _isExporting = false;
  String _loadingMsg = '';

  // A4 at 300 DPI: 2480 x 3508 px
  static const int _sheetW = 2480;
  static const int _sheetH = 3508;
  static const int _margin = 80;

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: _isLoading || _isExporting,
      message: _loadingMsg,
      child: Scaffold(
        backgroundColor: AppTheme.surface,
        appBar: AppBar(title: const Text('ID Card Front & Back'), leading: const BackButton()),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildInfo(),
                const SizedBox(height: 20),
                _buildImageRow(),
                const SizedBox(height: 20),
                _buildGenerateButton(),
                const SizedBox(height: 20),
                if (_sheetPng != null) ...[
                  _buildPreview(),
                  const SizedBox(height: 20),
                  _buildExportSection(),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInfo() => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: AppTheme.primary.withOpacity(0.05),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: AppTheme.primary.withOpacity(0.2)),
    ),
    child: const Row(children: [
      Icon(Icons.info_outline, size: 18, color: AppTheme.primary),
      SizedBox(width: 10),
      Expanded(child: Text(
        'Upload front and back of your ID card. Sheet will have FRONT on top and BACK below — one copy, A4 size.',
        style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
      )),
    ]),
  );

  Widget _buildImageRow() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // FRONT upload section
        const Text('Upload FRONT SIDE',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () => _pickImage(isFront: true),
            icon: const Icon(Icons.upload_outlined),
            label: Text(_frontFile == null ? 'Select Image' : 'Change Image'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 14),
              side: BorderSide(
                color: _frontFile != null ? AppTheme.success : AppTheme.primary,
                width: 1.5,
              ),
              foregroundColor: _frontFile != null ? AppTheme.success : AppTheme.primary,
            ),
          ),
        ),
        if (_frontFile != null) ...[
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.file(_frontFile!, height: 120, width: double.infinity, fit: BoxFit.cover),
          ),
          const SizedBox(height: 4),
          const Row(children: [
            Icon(Icons.check_circle, color: AppTheme.success, size: 14),
            SizedBox(width: 4),
            Text('Front uploaded', style: TextStyle(fontSize: 12, color: AppTheme.success, fontWeight: FontWeight.w600)),
          ]),
        ],
        const SizedBox(height: 20),
        // BACK upload section
        const Text('Upload BACK SIDE',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () => _pickImage(isFront: false),
            icon: const Icon(Icons.upload_outlined),
            label: Text(_backFile == null ? 'Select Image' : 'Change Image'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 14),
              side: BorderSide(
                color: _backFile != null ? AppTheme.success : AppTheme.primary,
                width: 1.5,
              ),
              foregroundColor: _backFile != null ? AppTheme.success : AppTheme.primary,
            ),
          ),
        ),
        if (_backFile != null) ...[
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.file(_backFile!, height: 120, width: double.infinity, fit: BoxFit.cover),
          ),
          const SizedBox(height: 4),
          const Row(children: [
            Icon(Icons.check_circle, color: AppTheme.success, size: 14),
            SizedBox(width: 4),
            Text('Back uploaded', style: TextStyle(fontSize: 12, color: AppTheme.success, fontWeight: FontWeight.w600)),
          ]),
        ],
      ],
    );
  }

  Widget _buildGenerateButton() {
    final bothUploaded = _frontFile != null && _backFile != null;
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: bothUploaded ? _generateSheet : null,
        icon: const Icon(Icons.layers_outlined),
        label: Text(bothUploaded ? 'GENERATE ID SHEET' : 'Upload both images to continue'),
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 16),
          backgroundColor: bothUploaded ? AppTheme.primary : AppTheme.border,
          foregroundColor: bothUploaded ? Colors.white : AppTheme.textSecondary,
        ),
      ),
    );
  }

  Widget _buildPreview() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Text('Sheet Preview', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
      const SizedBox(height: 12),
      Container(
        width: double.infinity,
        decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(16), border: Border.all(color: AppTheme.border)),
        child: AspectRatio(
          aspectRatio: _sheetW / _sheetH,
          child: ClipRRect(borderRadius: BorderRadius.circular(15), child: Image.memory(_sheetPng!, fit: BoxFit.cover)),
        ),
      ),
    ],
  );

  Widget _buildExportSection() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Export & Print', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: _ExBtn(icon: Icons.print_outlined, label: 'Print', color: AppTheme.primary, onTap: _print)),
        const SizedBox(width: 10),
        Expanded(child: _ExBtn(icon: Icons.picture_as_pdf_outlined, label: 'Save PDF', color: AppTheme.error, onTap: _savePdf)),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: _ExBtn(icon: Icons.image_outlined, label: 'Save JPG', color: const Color(0xFF0EA5E9), onTap: _saveJpg)),
        const SizedBox(width: 10),
        Expanded(child: _ExBtn(icon: Icons.photo_outlined, label: 'Save PNG', color: const Color(0xFF7C3AED), onTap: _savePng)),
      ]),
      const SizedBox(height: 10),
      SizedBox(width: double.infinity,
        child: _ExBtn(icon: Icons.photo_library_outlined, label: 'Save to Gallery', color: AppTheme.success, onTap: _saveToGallery)),
      const SizedBox(height: 24),
    ]);
  }

  Future<void> _pickImage({required bool isFront}) async {
    final src = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(leading: const Icon(Icons.camera_alt_outlined), title: const Text('Camera'), onTap: () => Navigator.pop(context, ImageSource.camera)),
        ListTile(leading: const Icon(Icons.photo_library_outlined), title: const Text('Gallery'), onTap: () => Navigator.pop(context, ImageSource.gallery)),
      ])),
    );
    if (src == null) return;
    setState(() { _isLoading = true; _loadingMsg = 'Processing image...'; });
    try {
      final xFile = await _picker.pickImage(source: src, imageQuality: 85, maxWidth: 2000);
      if (xFile == null) { setState(() => _isLoading = false); return; }
      final compressed = await ImageCompressUtil.compressToMaxWidth(File(xFile.path), maxWidth: 2000);
      if (mounted) setState(() {
        if (isFront) _frontFile = compressed; else _backFile = compressed;
        _sheetPng = null;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) _showSnack('Error: $e', isError: true);
    }
  }

  Future<void> _generateSheet() async {
    if (_frontFile == null || _backFile == null) return;
    setState(() { _isLoading = true; _loadingMsg = 'Generating sheet...'; });
    try {
      final frontBytes = await _frontFile!.readAsBytes();
      final backBytes  = await _backFile!.readAsBytes();
      final sheet = await Isolate.run(() => _buildSheet(frontBytes, backBytes));
      if (mounted) setState(() { _sheetPng = sheet; _isLoading = false; });
    } catch (e) {
      if (mounted) { setState(() => _isLoading = false); _showSnack('Failed: $e', isError: true); }
    }
  }

  static Uint8List _buildSheet(Uint8List frontBytes, Uint8List backBytes) {
    final sheet = img.Image(width: _sheetW, height: _sheetH, numChannels: 3);
    img.fill(sheet, color: img.ColorRgb8(255, 255, 255));

    final cellW = _sheetW - _margin * 2;
    final cellH = (_sheetH - _margin * 3) ~/ 2; // two halves with 3 margins

    void stamp(Uint8List bytes, int dstY) {
      final decoded = img.decodeImage(bytes);
      if (decoded == null) return;
      final scaleW = cellW / decoded.width;
      final scaleH = cellH / decoded.height;
      final scale = scaleW < scaleH ? scaleW : scaleH;
      final fitW = (decoded.width * scale).round();
      final fitH = (decoded.height * scale).round();
      final scaled = img.copyResize(decoded, width: fitW, height: fitH, interpolation: img.Interpolation.cubic);
      final offsetX = _margin + ((cellW - fitW) / 2).round();
      final offsetY = dstY + ((cellH - fitH) / 2).round();
      img.compositeImage(sheet, scaled, dstX: offsetX, dstY: offsetY);
    }

    stamp(frontBytes, _margin);                      // FRONT top
    stamp(backBytes,  _margin * 2 + cellH);          // BACK bottom

    // Divider line
    final divY = _margin + cellH + _margin ~/ 2;
    for (int x = _margin; x < _sheetW - _margin; x++) {
      sheet.setPixel(x, divY, img.ColorRgb8(220, 220, 220));
    }

    return Uint8List.fromList(img.encodePng(sheet));
  }

  Future<void> _print() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMsg = 'Preparing print...'; });
    try {
      final pdf = await _makePdf();
      await Printing.layoutPdf(onLayout: (_) async => pdf, name: 'ID Card Sheet');
    } catch (e) { if (mounted) _showSnack('Print failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  Future<void> _savePdf() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMsg = 'Generating PDF...'; });
    try {
      final pdf = await _makePdf();
      await Printing.sharePdf(bytes: pdf, filename: 'id_card_sheet.pdf');
    } catch (e) { if (mounted) _showSnack('PDF failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  Future<Uint8List> _makePdf() async {
    final doc = pw.Document(version: PdfVersion.pdf_1_5, compress: true);
    final pdfImg = pw.MemoryImage(_sheetPng!);
    const fmt = PdfPageFormat(210 * PdfPageFormat.mm, 297 * PdfPageFormat.mm, marginAll: 0);
    doc.addPage(pw.Page(pageFormat: fmt, margin: pw.EdgeInsets.zero,
        build: (_) => pw.Image(pdfImg, fit: pw.BoxFit.fill)));
    return doc.save();
  }

  Future<void> _saveJpg() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMsg = 'Saving JPG...'; });
    try {
      final jpgBytes = await Isolate.run(() {
        final d = img.decodeImage(_sheetPng!);
        if (d == null) throw Exception('decode failed');
        return Uint8List.fromList(img.encodeJpg(d, quality: 95));
      });
      final dir = await getExternalStorageDirectory() ?? await getTemporaryDirectory();
      final file = File('${dir.path}/id_sheet_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await file.writeAsBytes(jpgBytes);
      if (mounted) _showSnack('✅ Saved as JPG');
    } catch (e) { if (mounted) _showSnack('Save failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  Future<void> _savePng() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMsg = 'Saving PNG...'; });
    try {
      final dir = await getExternalStorageDirectory() ?? await getTemporaryDirectory();
      final file = File('${dir.path}/id_sheet_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_sheetPng!);
      if (mounted) _showSnack('✅ Saved as PNG');
    } catch (e) { if (mounted) _showSnack('Save failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  Future<void> _saveToGallery() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMsg = 'Saving to Gallery...'; });
    try {
      final dir = Directory('/storage/emulated/0/DCIM/SmartPrint');
      if (!await dir.exists()) await dir.create(recursive: true);
      final jpgBytes = await Isolate.run(() {
        final d = img.decodeImage(_sheetPng!);
        if (d == null) throw Exception('decode failed');
        return Uint8List.fromList(img.encodeJpg(d, quality: 95));
      });
      final file = File('${dir.path}/id_sheet_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await file.writeAsBytes(jpgBytes);
      if (mounted) _showSnack('✅ Saved to Gallery');
    } catch (e) { if (mounted) _showSnack('Gallery save failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? AppTheme.error : AppTheme.success,
      behavior: SnackBarBehavior.floating,
    ));
  }
}

class _ExBtn extends StatelessWidget {
  final IconData icon; final String label; final Color color; final VoidCallback onTap;
  const _ExBtn({required this.icon, required this.label, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      decoration: BoxDecoration(color: color.withOpacity(0.06), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(0.25), width: 1.5)),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(width: 8),
        Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: color)),
      ]),
    ),
  );
}

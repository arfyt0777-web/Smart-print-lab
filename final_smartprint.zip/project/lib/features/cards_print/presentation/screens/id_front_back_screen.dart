import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image/image.dart' as img;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../shared/widgets/loading_overlay.dart';

// ── Top-level functions for compute() ─────────────────────────────────────────

Uint8List _buildSheetIsolate(Map<String, Uint8List> args) {
  const int sheetW = 2480;
  const int sheetH = 3508;
  const int margin = 80;

  final frontBytes = args['front']!;
  final backBytes = args['back']!;

  final sheet = img.Image(width: sheetW, height: sheetH, numChannels: 3);
  img.fill(sheet, color: img.ColorRgb8(255, 255, 255));

  final cellW = sheetW - margin * 2;
  final cellH = (sheetH - margin * 3) ~/ 2;

  void stamp(Uint8List bytes, int dstY) {
    final decoded = img.decodeImage(bytes);
    if (decoded == null) return;
    final scaleW = cellW / decoded.width;
    final scaleH = cellH / decoded.height;
    final scale = scaleW < scaleH ? scaleW : scaleH;
    final fitW = (decoded.width * scale).round();
    final fitH = (decoded.height * scale).round();
    final scaled = img.copyResize(decoded, width: fitW, height: fitH, interpolation: img.Interpolation.linear);
    final offsetX = margin + ((cellW - fitW) / 2).round();
    final offsetY = dstY + ((cellH - fitH) / 2).round();
    img.compositeImage(sheet, scaled, dstX: offsetX, dstY: offsetY);
  }

  stamp(frontBytes, margin);
  stamp(backBytes, margin * 2 + cellH);

  final divY = margin + cellH + margin ~/ 2;
  for (int x = margin; x < sheetW - margin; x++) {
    sheet.setPixel(x, divY, img.ColorRgb8(220, 220, 220));
  }

  return Uint8List.fromList(img.encodePng(sheet));
}

Uint8List _encodeJpgIsolate(Uint8List pngBytes) {
  final d = img.decodeImage(pngBytes);
  if (d == null) throw Exception('decode failed');
  return Uint8List.fromList(img.encodeJpg(d, quality: 95));
}

Uint8List _cropIsolate(Map<String, dynamic> args) {
  final bytes = args['bytes'] as Uint8List;
  final cropX = args['cropX'] as int;
  final cropY = args['cropY'] as int;
  final cropW = args['cropW'] as int;
  final cropH = args['cropH'] as int;
  final src = img.decodeImage(bytes);
  if (src == null) throw Exception('decode failed');
  final cropped = img.copyCrop(src, x: cropX, y: cropY, width: cropW, height: cropH);
  return Uint8List.fromList(img.encodeJpg(cropped, quality: 95));
}

// ── Main Screen ───────────────────────────────────────────────────────────────

class IdFrontBackScreen extends StatefulWidget {
  const IdFrontBackScreen({super.key});
  @override
  State<IdFrontBackScreen> createState() => _IdFrontBackScreenState();
}

class _IdFrontBackScreenState extends State<IdFrontBackScreen> {
  final _picker = ImagePicker();
  File? _frontFile;
  File? _backFile;
  Uint8List? _sheetPng;
  bool _isLoading = false;
  bool _isExporting = false;
  String _loadingMsg = '';

  static const int _sheetW = 2480;
  static const int _sheetH = 3508;

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: _isLoading || _isExporting,
      message: _loadingMsg,
      child: Scaffold(
        backgroundColor: AppTheme.surface,
        appBar: AppBar(title: const Text('ID Card Front & Back'), leading: const BackButton()),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildInfo(),
                const SizedBox(height: 20),
                _buildImageRow(),
                const SizedBox(height: 20),
                _buildGenerateButton(),
                const SizedBox(height: 20),
                if (_sheetPng != null) ...[
                  _buildPreview(),
                  const SizedBox(height: 20),
                  _buildExportSection(),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInfo() => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: AppTheme.primary.withOpacity(0.05),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: AppTheme.primary.withOpacity(0.2)),
    ),
    child: const Row(children: [
      Icon(Icons.info_outline, size: 18, color: AppTheme.primary),
      SizedBox(width: 10),
      Expanded(child: Text(
        'Upload front and back of your ID card. Crop each image as needed. Sheet will have FRONT on top and BACK below — A4 size.',
        style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
      )),
    ]),
  );

  Widget _buildImageRow() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSideSection(label: 'FRONT SIDE', file: _frontFile, isFront: true),
        const SizedBox(height: 20),
        _buildSideSection(label: 'BACK SIDE', file: _backFile, isFront: false),
      ],
    );
  }

  Widget _buildSideSection({required String label, required File? file, required bool isFront}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Upload $label',
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () => _pickImage(isFront: isFront),
            icon: const Icon(Icons.upload_outlined),
            label: Text(file == null ? 'Select Image' : 'Change Image'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 14),
              side: BorderSide(color: file != null ? AppTheme.success : AppTheme.primary, width: 1.5),
              foregroundColor: file != null ? AppTheme.success : AppTheme.primary,
            ),
          ),
        ),
        if (file != null) ...[
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.file(file, height: 120, width: double.infinity, fit: BoxFit.contain),
          ),
          const SizedBox(height: 4),
          const Row(children: [
            Icon(Icons.check_circle, color: AppTheme.success, size: 14),
            SizedBox(width: 4),
            Text('Uploaded', style: TextStyle(fontSize: 12, color: AppTheme.success, fontWeight: FontWeight.w600)),
          ]),
        ],
      ],
    );
  }

  Widget _buildGenerateButton() {
    final bothUploaded = _frontFile != null && _backFile != null;
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: bothUploaded ? _generateSheet : null,
        icon: const Icon(Icons.layers_outlined),
        label: Text(bothUploaded ? 'GENERATE ID SHEET' : 'Upload both images to continue'),
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 16),
          backgroundColor: bothUploaded ? AppTheme.primary : AppTheme.border,
          foregroundColor: bothUploaded ? Colors.white : AppTheme.textSecondary,
        ),
      ),
    );
  }

  Widget _buildPreview() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Text('Sheet Preview', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
      const SizedBox(height: 12),
      Container(
        width: double.infinity,
        decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(16), border: Border.all(color: AppTheme.border)),
        child: AspectRatio(
          aspectRatio: _sheetW / _sheetH,
          child: ClipRRect(borderRadius: BorderRadius.circular(15), child: Image.memory(_sheetPng!, fit: BoxFit.fill)),
        ),
      ),
    ],
  );

  Widget _buildExportSection() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Export & Print', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: _ExBtn(icon: Icons.print_outlined, label: 'Print', color: AppTheme.primary, onTap: _print)),
        const SizedBox(width: 10),
        Expanded(child: _ExBtn(icon: Icons.picture_as_pdf_outlined, label: 'Save PDF', color: AppTheme.error, onTap: _savePdf)),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: _ExBtn(icon: Icons.image_outlined, label: 'Save JPG', color: const Color(0xFF0EA5E9), onTap: _saveJpg)),
        const SizedBox(width: 10),
        Expanded(child: _ExBtn(icon: Icons.photo_outlined, label: 'Save PNG', color: const Color(0xFF7C3AED), onTap: _savePng)),
      ]),
      const SizedBox(height: 10),
      SizedBox(width: double.infinity,
        child: _ExBtn(icon: Icons.photo_library_outlined, label: 'Save to Gallery', color: AppTheme.success, onTap: _saveToGallery)),
      const SizedBox(height: 24),
    ]);
  }

  Future<void> _pickImage({required bool isFront}) async {
    final src = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(leading: const Icon(Icons.camera_alt_outlined), title: const Text('Camera'), onTap: () => Navigator.pop(context, ImageSource.camera)),
        ListTile(leading: const Icon(Icons.photo_library_outlined), title: const Text('Gallery'), onTap: () => Navigator.pop(context, ImageSource.gallery)),
      ])),
    );
    if (src == null) return;

    setState(() { _isLoading = true; _loadingMsg = 'Opening...'; });
    try {
      final xFile = await _picker.pickImage(source: src, imageQuality: 88, maxWidth: 1500);
      if (xFile == null) { setState(() => _isLoading = false); return; }
      setState(() => _isLoading = false);

      if (!mounted) return;
      final cropped = await Navigator.push<File>(
        context,
        MaterialPageRoute(builder: (_) => _CropScreen(imageFile: File(xFile.path))),
      );
      if (cropped == null) return;

      if (mounted) setState(() {
        if (isFront) _frontFile = cropped; else _backFile = cropped;
        _sheetPng = null;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) _showSnack('Error: $e', isError: true);
    }
  }

  Future<void> _generateSheet() async {
    if (_frontFile == null || _backFile == null) return;
    setState(() { _isLoading = true; _loadingMsg = 'Generating sheet...'; });
    try {
      final frontBytes = await _frontFile!.readAsBytes();
      final backBytes  = await _backFile!.readAsBytes();
      final sheet = await compute(_buildSheetIsolate, {'front': frontBytes, 'back': backBytes});
      if (mounted) setState(() { _sheetPng = sheet; _isLoading = false; });
    } catch (e) {
      if (mounted) { setState(() => _isLoading = false); _showSnack('Failed: $e', isError: true); }
    }
  }

  Future<void> _print() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMsg = 'Preparing print...'; });
    try {
      final pdf = await _makePdf();
      await Printing.layoutPdf(onLayout: (_) async => pdf, name: 'ID Card Sheet');
    } catch (e) { if (mounted) _showSnack('Print failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  Future<void> _savePdf() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMsg = 'Generating PDF...'; });
    try {
      final pdf = await _makePdf();
      await Printing.sharePdf(bytes: pdf, filename: 'id_card_sheet.pdf');
    } catch (e) { if (mounted) _showSnack('PDF failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  Future<Uint8List> _makePdf() async {
    final doc = pw.Document(version: PdfVersion.pdf_1_5, compress: true);
    final pdfImg = pw.MemoryImage(_sheetPng!);
    const fmt = PdfPageFormat(210 * PdfPageFormat.mm, 297 * PdfPageFormat.mm, marginAll: 0);
    doc.addPage(pw.Page(pageFormat: fmt, margin: pw.EdgeInsets.zero,
        build: (_) => pw.Image(pdfImg, fit: pw.BoxFit.fill)));
    return doc.save();
  }

  Future<void> _saveJpg() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMsg = 'Saving JPG...'; });
    try {
      final jpgBytes = await compute(_encodeJpgIsolate, _sheetPng!);
      final dir = await getExternalStorageDirectory() ?? await getTemporaryDirectory();
      final file = File('${dir.path}/id_sheet_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await file.writeAsBytes(jpgBytes);
      if (mounted) _showSnack('✅ Saved as JPG');
    } catch (e) { if (mounted) _showSnack('Save failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  Future<void> _savePng() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMsg = 'Saving PNG...'; });
    try {
      final dir = await getExternalStorageDirectory() ?? await getTemporaryDirectory();
      final file = File('${dir.path}/id_sheet_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_sheetPng!);
      if (mounted) _showSnack('✅ Saved as PNG');
    } catch (e) { if (mounted) _showSnack('Save failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  Future<void> _saveToGallery() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMsg = 'Saving to Gallery...'; });
    try {
      final dir = Directory('/storage/emulated/0/DCIM/SmartPrint');
      if (!await dir.exists()) await dir.create(recursive: true);
      final jpgBytes = await compute(_encodeJpgIsolate, _sheetPng!);
      final file = File('${dir.path}/id_sheet_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await file.writeAsBytes(jpgBytes);
      if (mounted) _showSnack('✅ Saved to Gallery');
    } catch (e) { if (mounted) _showSnack('Gallery save failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? AppTheme.error : AppTheme.success,
      behavior: SnackBarBehavior.floating,
    ));
  }
}

// ── Manual 4-side Crop Screen ─────────────────────────────────────────────────

class _CropScreen extends StatefulWidget {
  final File imageFile;
  const _CropScreen({required this.imageFile});
  @override
  State<_CropScreen> createState() => _CropScreenState();
}

class _CropScreenState extends State<_CropScreen> {
  late Future<_CropData> _initFuture;

  @override
  void initState() {
    super.initState();
    _initFuture = _load();
  }

  Future<_CropData> _load() async {
    final bytes = await widget.imageFile.readAsBytes();
    final decoded = img.decodeImage(bytes);
    if (decoded == null) throw Exception('Cannot decode image');
    return _CropData(bytes: bytes, w: decoded.width.toDouble(), h: decoded.height.toDouble());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: const Text('Crop Image', style: TextStyle(color: Colors.white)),
        leading: const BackButton(color: Colors.white),
      ),
      body: FutureBuilder<_CropData>(
        future: _initFuture,
        builder: (context, snap) {
          if (snap.hasError) return Center(child: Text('Error: ${snap.error}', style: const TextStyle(color: Colors.white)));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: AppTheme.primary));
          return _CropEditor(imageFile: widget.imageFile, data: snap.data!);
        },
      ),
    );
  }
}

class _CropData {
  final Uint8List bytes;
  final double w, h;
  const _CropData({required this.bytes, required this.w, required this.h});
}

class _CropEditor extends StatefulWidget {
  final File imageFile;
  final _CropData data;
  const _CropEditor({required this.imageFile, required this.data});
  @override
  State<_CropEditor> createState() => _CropEditorState();
}

class _CropEditorState extends State<_CropEditor> {
  double _left = 0.0, _top = 0.0, _right = 1.0, _bottom = 1.0;
  bool _isSaving = false;

  static const double _handleSize = 28;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: LayoutBuilder(builder: (context, constraints) {
            final dispW = constraints.maxWidth;
            final dispH = constraints.maxHeight;

            final imgAR = widget.data.w / widget.data.h;
            final dispAR = dispW / dispH;
            double imgDispW, imgDispH, imgOffX, imgOffY;
            if (imgAR > dispAR) {
              imgDispW = dispW;
              imgDispH = dispW / imgAR;
              imgOffX = 0;
              imgOffY = (dispH - imgDispH) / 2;
            } else {
              imgDispH = dispH;
              imgDispW = dispH * imgAR;
              imgOffX = (dispW - imgDispW) / 2;
              imgOffY = 0;
            }

            final rx = imgDispW;
            final ry = imgDispH;

            final cropL = imgOffX + _left * rx;
            final cropT = imgOffY + _top * ry;
            final cropR = imgOffX + _right * rx;
            final cropB = imgOffY + _bottom * ry;

            return GestureDetector(
              onTap: () {},
              child: Stack(
                children: [
                  Positioned.fill(child: Image.file(widget.imageFile, fit: BoxFit.contain)),
                  Positioned.fill(child: CustomPaint(painter: _DimPainter(cropRect: Rect.fromLTRB(cropL, cropT, cropR, cropB)))),
                  Positioned(left: cropL, top: cropT, width: cropR - cropL, height: cropB - cropT,
                    child: Container(decoration: BoxDecoration(border: Border.all(color: Colors.white, width: 1.5)))),
                  Positioned(left: cropL, top: cropT, width: cropR - cropL, height: cropB - cropT,
                    child: CustomPaint(painter: _GridPainter())),
                  _handle(cropL, cropT, (dx, dy) {
                    setState(() { _left = (_left + dx / rx).clamp(0.0, _right - 0.05); _top = (_top + dy / ry).clamp(0.0, _bottom - 0.05); });
                  }),
                  _handle(cropR - _handleSize, cropT, (dx, dy) {
                    setState(() { _right = (_right + dx / rx).clamp(_left + 0.05, 1.0); _top = (_top + dy / ry).clamp(0.0, _bottom - 0.05); });
                  }),
                  _handle(cropL, cropB - _handleSize, (dx, dy) {
                    setState(() { _left = (_left + dx / rx).clamp(0.0, _right - 0.05); _bottom = (_bottom + dy / ry).clamp(_top + 0.05, 1.0); });
                  }),
                  _handle(cropR - _handleSize, cropB - _handleSize, (dx, dy) {
                    setState(() { _right = (_right + dx / rx).clamp(_left + 0.05, 1.0); _bottom = (_bottom + dy / ry).clamp(_top + 0.05, 1.0); });
                  }),
                  _handle((cropL + cropR) / 2 - _handleSize / 2, cropT, (dx, dy) {
                    setState(() => _top = (_top + dy / ry).clamp(0.0, _bottom - 0.05));
                  }),
                  _handle((cropL + cropR) / 2 - _handleSize / 2, cropB - _handleSize, (dx, dy) {
                    setState(() => _bottom = (_bottom + dy / ry).clamp(_top + 0.05, 1.0));
                  }),
                  _handle(cropL, (cropT + cropB) / 2 - _handleSize / 2, (dx, dy) {
                    setState(() => _left = (_left + dx / rx).clamp(0.0, _right - 0.05));
                  }),
                  _handle(cropR - _handleSize, (cropT + cropB) / 2 - _handleSize / 2, (dx, dy) {
                    setState(() => _right = (_right + dx / rx).clamp(_left + 0.05, 1.0));
                  }),
                ],
              ),
            );
          }),
        ),
        Container(
          color: Colors.black,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white54), padding: const EdgeInsets.symmetric(vertical: 14)),
                  child: const Text('Cancel'),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: ElevatedButton(
                  onPressed: _isSaving ? null : _applyCrop,
                  style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primary, padding: const EdgeInsets.symmetric(vertical: 14)),
                  child: _isSaving
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('Use Photo', style: TextStyle(fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _handle(double left, double top, void Function(double dx, double dy) onDrag) {
    return Positioned(
      left: left, top: top,
      child: GestureDetector(
        onPanUpdate: (d) => onDrag(d.delta.dx, d.delta.dy),
        child: Container(
          width: _handleSize, height: _handleSize,
          decoration: BoxDecoration(
            color: AppTheme.primary, shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 2),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 4)],
          ),
        ),
      ),
    );
  }

  Future<void> _applyCrop() async {
    setState(() => _isSaving = true);
    try {
      final bytes = widget.data.bytes;
      final iw = widget.data.w.round();
      final ih = widget.data.h.round();
      final cropX = (_left * iw).round();
      final cropY = (_top * ih).round();
      final cropW = ((_right - _left) * iw).round().clamp(1, iw - cropX);
      final cropH = ((_bottom - _top) * ih).round().clamp(1, ih - cropY);

      final outBytes = await compute(_cropIsolate, {
        'bytes': bytes,
        'cropX': cropX,
        'cropY': cropY,
        'cropW': cropW,
        'cropH': cropH,
      });

      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/crop_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await file.writeAsBytes(outBytes);
      if (mounted) Navigator.pop(context, file);
    } catch (e) {
      setState(() => _isSaving = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Crop failed: $e'), backgroundColor: AppTheme.error),
        );
      }
    }
  }
}

class _DimPainter extends CustomPainter {
  final Rect cropRect;
  const _DimPainter({required this.cropRect});
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.black.withOpacity(0.55);
    final full = Rect.fromLTWH(0, 0, size.width, size.height);
    final path = Path()..addRect(full)..addRect(cropRect)..fillType = PathFillType.evenOdd;
    canvas.drawPath(path, paint);
  }
  @override
  bool shouldRepaint(_DimPainter old) => old.cropRect != cropRect;
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.3)..strokeWidth = 0.5;
    canvas.drawLine(Offset(size.width / 3, 0), Offset(size.width / 3, size.height), paint);
    canvas.drawLine(Offset(size.width * 2 / 3, 0), Offset(size.width * 2 / 3, size.height), paint);
    canvas.drawLine(Offset(0, size.height / 3), Offset(size.width, size.height / 3), paint);
    canvas.drawLine(Offset(0, size.height * 2 / 3), Offset(size.width, size.height * 2 / 3), paint);
  }
  @override
  bool shouldRepaint(_GridPainter _) => false;
}

class _ExBtn extends StatelessWidget {
  final IconData icon; final String label; final Color color; final VoidCallback onTap;
  const _ExBtn({required this.icon, required this.label, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      decoration: BoxDecoration(color: color.withOpacity(0.06), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(0.25), width: 1.5)),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(width: 8),
        Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: color)),
      ]),
    ),
  );
}

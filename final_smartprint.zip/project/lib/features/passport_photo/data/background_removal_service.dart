import 'dart:io';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import '../../../core/config/app_config.dart';

class BackgroundRemovalService {
  static const int _timeoutSeconds = 30;
  static const int _retriesPerKey = 2;

  static Future<Uint8List> removeBackground(File imageFile) async {
    final keys = AppConfig.removeBgApiKeys;
    if (keys.isEmpty) {
      throw Exception('No remove.bg API key configured.\nAdd REMOVE_BG_API_KEY in Codemagic environment variables.');
    }

    final imageBytes = await imageFile.readAsBytes();
    final extension = imageFile.path.split('.').last.toLowerCase();

    Object? lastError;
    for (final key in keys) {
      for (int attempt = 1; attempt <= _retriesPerKey; attempt++) {
        try {
          final result = await _callRemoveBg(imageBytes, extension, key);
          return result;
        } catch (e) {
          lastError = e;
          final msg = e.toString();
          if (msg.contains('402') || msg.contains('429')) break;
          if (attempt < _retriesPerKey) {
            await Future.delayed(const Duration(seconds: 1));
            continue;
          }
        }
      }
    }
    throw Exception('All remove.bg keys failed.\nLast error: $lastError');
  }

  // HTTP call on main isolate — fixes DNS/SocketException on Android
  static Future<Uint8List> _callRemoveBg(
      Uint8List imageBytes, String extension, String apiKey) async {
    final uri = Uri.parse('${AppConfig.removeBgBaseUrl}/removebg');
    final mimeType = extension == 'png' ? 'image/png' : 'image/jpeg';

    final request = http.MultipartRequest('POST', uri)
      ..headers['X-Api-Key'] = apiKey
      ..fields['size'] = 'auto'
      ..files.add(http.MultipartFile.fromBytes(
        'image_file', imageBytes,
        filename: 'photo.$extension',
        contentType: MediaType.parse(mimeType),
      ));

    final streamedResponse = await request.send().timeout(
      const Duration(seconds: _timeoutSeconds),
      onTimeout: () => throw Exception('remove.bg timeout after ${_timeoutSeconds}s'),
    );

    final responseBytes = await streamedResponse.stream.toBytes();
    if (streamedResponse.statusCode == 200) return responseBytes;

    final body = String.fromCharCodes(responseBytes);
    throw Exception('remove.bg error ${streamedResponse.statusCode}: $body');
  }
}

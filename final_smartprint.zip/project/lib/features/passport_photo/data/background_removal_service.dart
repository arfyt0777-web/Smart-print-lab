import 'dart:io';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import 'package:google_mlkit_selfie_segmentation/google_mlkit_selfie_segmentation.dart';
import 'package:image/image.dart' as img;
import '../../../core/config/app_config.dart';

class BackgroundRemovalService {
  static const int _timeoutSeconds = 60;
  static const int _retriesPerKey = 2;

  /// Tries remove.bg API first (Dio — fixes Android DNS).
  /// If API fails for any reason → falls back to on-device MLKit.
  static Future<Uint8List> removeBackground(
    File imageFile, {
    void Function(String)? onStatusUpdate,
  }) async {
    // ── Step 1: Try remove.bg API ─────────────────────────────────────────
    final keys = AppConfig.removeBgApiKeys;
    if (keys.isNotEmpty) {
      onStatusUpdate?.call('Removing background with AI…');
      try {
        final result = await _tryRemoveBgApi(imageFile, keys);
        if (result != null) return result;
      } catch (_) {}
    }

    // ── Step 2: On-device MLKit fallback ─────────────────────────────────
    onStatusUpdate?.call('Using on-device AI (no internet needed)…');
    return await _removeBackgroundOnDevice(imageFile);
  }

  // ── remove.bg via Dio ─────────────────────────────────────────────────────
  static Future<Uint8List?> _tryRemoveBgApi(
      File imageFile, List<String> keys) async {
    final extension = imageFile.path.split('.').last.toLowerCase();
    final mimeType = extension == 'png' ? 'image/png' : 'image/jpeg';

    final dio = Dio(BaseOptions(
      connectTimeout: const Duration(seconds: _timeoutSeconds),
      receiveTimeout: const Duration(seconds: _timeoutSeconds),
      responseType: ResponseType.bytes,
    ));

    try {
      for (final key in keys) {
        if (key.length < 10) continue;
        for (int attempt = 1; attempt <= _retriesPerKey; attempt++) {
          try {
            final formData = FormData.fromMap({
              'image_file': await MultipartFile.fromFile(
                imageFile.path,
                filename: 'photo.$extension',
                contentType: DioMediaType.parse(mimeType),
              ),
              'size': 'auto',
            });

            final response = await dio.post(
              '${AppConfig.removeBgBaseUrl}/removebg',
              data: formData,
              options: Options(headers: {'X-Api-Key': key}),
            );

            if (response.statusCode == 200) {
              return Uint8List.fromList(response.data as List<int>);
            }
          } on DioException catch (e) {
            final status = e.response?.statusCode;
            if (status == 403 || status == 402) return null;
            if (status == 429) break;
            if (attempt < _retriesPerKey) {
              await Future.delayed(const Duration(seconds: 2));
            }
          }
        }
      }
    } finally {
      dio.close();
    }
    return null;
  }

  // ── On-device ML via Google MLKit Selfie Segmentation ────────────────────
  static Future<Uint8List> _removeBackgroundOnDevice(File imageFile) async {
    final segmenter = SelfieSegmenter(
      mode: SegmenterMode.single,
      enableRawSizeMask: true,
    );

    try {
      final inputImage = InputImage.fromFile(imageFile);
      final mask = await segmenter.processImage(inputImage);

      if (mask == null) throw Exception('On-device segmentation failed');

      final originalBytes = await imageFile.readAsBytes();
      final original = img.decodeImage(originalBytes);
      if (original == null) throw Exception('Cannot decode image');

      final maskW = mask.width;
      final maskH = mask.height;
      final confidence = mask.confidences;

      // Scale original to mask dimensions for pixel mapping
      final scaled = img.copyResize(original, width: maskW, height: maskH);

      // Build RGBA output — transparent where background
      final output = img.Image(width: maskW, height: maskH, numChannels: 4);

      for (int y = 0; y < maskH; y++) {
        for (int x = 0; x < maskW; x++) {
          final idx = y * maskW + x;
          final conf = confidence[idx]; // 1.0 = person, 0.0 = background
          final pixel = scaled.getPixel(x, y);
          final alpha = (conf * 255).round().clamp(0, 255);
          output.setPixelRgba(
            x, y,
            pixel.r.toInt(),
            pixel.g.toInt(),
            pixel.b.toInt(),
            alpha,
          );
        }
      }

      // Scale back to original size
      final finalImg = img.copyResize(
        output,
        width: original.width,
        height: original.height,
      );

      return Uint8List.fromList(img.encodePng(finalImg));
    } finally {
      segmenter.close();
    }
  }
}

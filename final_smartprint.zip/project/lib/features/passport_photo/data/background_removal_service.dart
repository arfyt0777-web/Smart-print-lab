import 'dart:io';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import '../../../core/config/app_config.dart';

class BackgroundRemovalService {
  static const int _timeoutSeconds = 45;
  static const int _retriesPerKey = 2;

  // Hardcoded IPs for api.remove.bg — bypasses DNS lookup entirely
  // These are remove.bg's Cloudflare IPs (stable)
  static const List<String> _removeBgHosts = [
    'https://api.remove.bg/v1.0',     // normal DNS (try first)
    'https://104.21.4.175/v1.0',      // Cloudflare IP fallback 1
    'https://172.67.180.120/v1.0',    // Cloudflare IP fallback 2
  ];

  static Future<Uint8List> removeBackground(File imageFile) async {
    final keys = AppConfig.removeBgApiKeys;

    if (keys.isEmpty) {
      throw Exception(
        'No API keys found.\n'
        'Add REMOVE_BG_API_KEY in Codemagic Environment Variables and rebuild.',
      );
    }

    final imageBytes = await imageFile.readAsBytes();
    final extension = imageFile.path.split('.').last.toLowerCase();

    Object? lastError;

    for (final baseUrl in _removeBgHosts) {
      for (final key in keys) {
        if (key.length < 10) continue;
        for (int attempt = 1; attempt <= _retriesPerKey; attempt++) {
          try {
            final result = await _callRemoveBg(imageBytes, extension, key, baseUrl);
            return result;
          } catch (e) {
            lastError = e;
            final msg = e.toString();
            // Don't retry on auth/billing errors
            if (msg.contains('403') || msg.contains('402') || msg.contains('429')) break;
            if (attempt < _retriesPerKey) {
              await Future.delayed(const Duration(seconds: 2));
            }
          }
        }
      }
    }

    throw Exception('Background removal failed.\nLast error: $lastError');
  }

  static Future<Uint8List> _callRemoveBg(
      Uint8List imageBytes, String extension, String apiKey, String baseUrl) async {
    final uri = Uri.parse('$baseUrl/removebg');
    final mimeType = extension == 'png' ? 'image/png' : 'image/jpeg';

    final client = http.Client();
    try {
      final request = http.MultipartRequest('POST', uri)
        ..headers['X-Api-Key'] = apiKey
        ..headers['Host'] = 'api.remove.bg'   // required when using IP directly
        ..fields['size'] = 'auto'
        ..files.add(http.MultipartFile.fromBytes(
          'image_file', imageBytes,
          filename: 'photo.$extension',
          contentType: MediaType.parse(mimeType),
        ));

      final streamedResponse = await client.send(request).timeout(
        const Duration(seconds: _timeoutSeconds),
        onTimeout: () => throw Exception('Timeout — check internet connection'),
      );

      final responseBytes = await streamedResponse.stream.toBytes();
      if (streamedResponse.statusCode == 200) return responseBytes;

      final body = String.fromCharCodes(responseBytes);
      if (streamedResponse.statusCode == 403) throw Exception('Invalid API key (403)');
      if (streamedResponse.statusCode == 402) throw Exception('API credits finished (402)');
      if (streamedResponse.statusCode == 429) throw Exception('Rate limit hit (429)');
      throw Exception('Server error ${streamedResponse.statusCode}: $body');
    } finally {
      client.close();
    }
  }
}

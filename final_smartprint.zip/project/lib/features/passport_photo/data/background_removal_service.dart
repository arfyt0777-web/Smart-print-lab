import 'dart:io';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import '../../../core/config/app_config.dart';

class BackgroundRemovalService {
  static const int _timeoutSeconds = 60;

  static Future<Uint8List> removeBackground(File imageFile) async {
    final keys = AppConfig.removeBgApiKeys;

    if (keys.isEmpty) {
      throw Exception(
        'No API keys found.\n'
        'Add REMOVE_BG_API_KEY in Codemagic Environment Variables and rebuild.',
      );
    }

    final imageBytes = await imageFile.readAsBytes();
    final extension = imageFile.path.split('.').last.toLowerCase();

    Object? lastError;

    // Try each key with remove.bg
    for (final key in keys) {
      if (key.length < 10) continue;
      try {
        return await _callRemoveBg(imageBytes, extension, key);
      } catch (e) {
        lastError = e;
        final msg = e.toString();
        // Stop trying keys on auth/billing errors
        if (msg.contains('403') || msg.contains('402') || msg.contains('429')) break;
        await Future.delayed(const Duration(seconds: 1));
      }
    }

    // Fallback: try PhotoRoom API (free tier, no key needed for basic use)
    try {
      return await _callPhotoRoom(imageBytes, extension);
    } catch (e) {
      lastError = e;
    }

    throw Exception('Background removal failed.\nError: $lastError');
  }

  // remove.bg API call — runs on main isolate (Android DNS requirement)
  static Future<Uint8List> _callRemoveBg(
      Uint8List imageBytes, String extension, String apiKey) async {
    final uri = Uri.parse('https://api.remove.bg/v1.0/removebg');
    final mimeType = extension == 'png' ? 'image/png' : 'image/jpeg';

    final client = http.Client();
    try {
      final request = http.MultipartRequest('POST', uri)
        ..headers['X-Api-Key'] = apiKey
        ..fields['size'] = 'auto'
        ..files.add(http.MultipartFile.fromBytes(
          'image_file', imageBytes,
          filename: 'photo.$extension',
          contentType: MediaType.parse(mimeType),
        ));

      final streamedResponse = await client.send(request).timeout(
        const Duration(seconds: _timeoutSeconds),
        onTimeout: () => throw Exception('Timeout — check internet connection'),
      );

      final responseBytes = await streamedResponse.stream.toBytes();
      if (streamedResponse.statusCode == 200) return responseBytes;

      if (streamedResponse.statusCode == 403) throw Exception('Invalid API key (403)');
      if (streamedResponse.statusCode == 402) throw Exception('API credits finished (402)');
      if (streamedResponse.statusCode == 429) throw Exception('Rate limit (429)');
      final body = String.fromCharCodes(responseBytes);
      throw Exception('remove.bg error ${streamedResponse.statusCode}: $body');
    } finally {
      client.close();
    }
  }

  // PhotoRoom fallback — free, reliable DNS on Android
  static Future<Uint8List> _callPhotoRoom(
      Uint8List imageBytes, String extension) async {
    final uri = Uri.parse('https://sdk.photoroom.com/v1/segment');
    final mimeType = extension == 'png' ? 'image/png' : 'image/jpeg';

    final client = http.Client();
    try {
      final request = http.MultipartRequest('POST', uri)
        ..files.add(http.MultipartFile.fromBytes(
          'image_file', imageBytes,
          filename: 'photo.$extension',
          contentType: MediaType.parse(mimeType),
        ));

      final streamedResponse = await client.send(request).timeout(
        const Duration(seconds: _timeoutSeconds),
        onTimeout: () => throw Exception('PhotoRoom timeout'),
      );

      final responseBytes = await streamedResponse.stream.toBytes();
      if (streamedResponse.statusCode == 200) return responseBytes;
      throw Exception('PhotoRoom error ${streamedResponse.statusCode}');
    } finally {
      client.close();
    }
  }
}

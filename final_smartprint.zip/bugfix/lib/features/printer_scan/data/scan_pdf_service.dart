import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'printer_scan_models.dart';

/// Size preset targets in bytes
class ScanSizePreset {
  final String label;
  final int minBytes;
  final int maxBytes;
  const ScanSizePreset(this.label, this.minBytes, this.maxBytes);

  static const preset5to10kb   = ScanSizePreset('5 KB – 10 KB',    5000,   10000);
  static const preset50to100kb = ScanSizePreset('50 KB – 100 KB',  50000,  100000);
  static const preset500kbto1mb= ScanSizePreset('500 KB – 1 MB',   500000, 1000000);
  static const presetOriginal  = ScanSizePreset('Original Quality', 0,      0);

  static const all = [preset5to10kb, preset50to100kb, preset500kbto1mb, presetOriginal];
}

class ScanPdfService {
  /// Combines multiple scanned pages into a single PDF.
  /// If [sizePreset] is provided, compresses each page to fit target size range.
  static Future<File> generatePdf(
    List<ScannedPage> pages, {
    String fileName = 'scan',
    int dpi = 300,
    ScanSizePreset? sizePreset,
  }) async {
    final pdf = pw.Document(version: PdfVersion.pdf_1_5, compress: true);

    for (final page in pages) {
      Uint8List pageBytes = page.imageBytes;
      if (sizePreset != null && sizePreset.maxBytes > 0) {
        pageBytes = _compressToTargetSize(pageBytes, sizePreset);
      }

      final decoded = img.decodeImage(pageBytes);
      if (decoded == null) continue;

      final widthPt  = decoded.width  / dpi * 72.0;
      final heightPt = decoded.height / dpi * 72.0;

      final pdfImage = pw.MemoryImage(pageBytes);
      final pageFormat = PdfPageFormat(widthPt, heightPt, marginAll: 0);

      pdf.addPage(pw.Page(
        pageFormat: pageFormat,
        margin: pw.EdgeInsets.zero,
        build: (_) => pw.Image(pdfImage, fit: pw.BoxFit.fill),
      ));
    }

    final dir = await getTemporaryDirectory();
    final ts  = DateTime.now().millisecondsSinceEpoch;
    final file = File('${dir.path}/${fileName}_$ts.pdf');
    await file.writeAsBytes(await pdf.save());
    return file;
  }

  /// Saves all pages as individual JPG files compressed to target size.
  /// Returns list of saved files.
  static Future<List<File>> saveAsJpg(
    List<ScannedPage> pages, {
    String fileName = 'scan',
    ScanSizePreset? sizePreset,
  }) async {
    final dir = await getExternalStorageDirectory() ?? await getTemporaryDirectory();
    final saved = <File>[];
    final ts = DateTime.now().millisecondsSinceEpoch;

    for (int i = 0; i < pages.length; i++) {
      Uint8List pageBytes = pages[i].imageBytes;
      if (sizePreset != null && sizePreset.maxBytes > 0) {
        pageBytes = _compressToTargetSize(pageBytes, sizePreset);
      } else {
        // Ensure output is JPG even if original is not
        final decoded = img.decodeImage(pageBytes);
        if (decoded != null) {
          pageBytes = Uint8List.fromList(img.encodeJpg(decoded, quality: 95));
        }
      }
      final file = File('${dir.path}/${fileName}_p${i + 1}_$ts.jpg');
      await file.writeAsBytes(pageBytes);
      saved.add(file);
    }
    return saved;
  }

  /// Compresses image bytes to fit within [preset] size range using binary search on quality.
  static Uint8List _compressToTargetSize(Uint8List bytes, ScanSizePreset preset) {
    img.Image? src = img.decodeImage(bytes);
    if (src == null) return bytes;

    // For very small targets, also downscale resolution
    if (preset.maxBytes <= 10000) {
      src = img.copyResize(src, width: (src.width * 0.3).round(),
          interpolation: img.Interpolation.linear);
    } else if (preset.maxBytes <= 100000) {
      src = img.copyResize(src, width: (src.width * 0.6).round(),
          interpolation: img.Interpolation.linear);
    }

    // Binary search on JPEG quality to hit target size range
    int lo = 5, hi = 95, bestQuality = 50;
    Uint8List result = bytes;

    for (int attempt = 0; attempt < 10; attempt++) {
      final mid = (lo + hi) ~/ 2;
      final candidate = Uint8List.fromList(img.encodeJpg(src!, quality: mid));
      result = candidate;
      bestQuality = mid;

      if (candidate.length < preset.minBytes) {
        lo = mid + 1; // too small, increase quality
      } else if (candidate.length > preset.maxBytes) {
        hi = mid - 1; // too large, reduce quality
      } else {
        break; // within target range
      }
    }
    return result;
  }

  /// Enhance scanned image: denoise + sharpen for documents.
  static Uint8List enhanceScan(Uint8List bytes) {
    img.Image? src = img.decodeImage(bytes);
    if (src == null) return bytes;

    src = img.adjustColor(src, contrast: 1.15, brightness: 1.02);
    src = img.convolution(src, filter: [
      0, -0.5, 0,
      -0.5, 3, -0.5,
      0, -0.5, 0,
    ], div: 1, offset: 0);

    return Uint8List.fromList(img.encodeJpg(src, quality: 100));
  }
}


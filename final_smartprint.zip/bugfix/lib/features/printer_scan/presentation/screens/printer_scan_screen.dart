import 'dart:io';
import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../shared/widgets/loading_overlay.dart';
import '../../data/printer_scan_models.dart';
import '../../data/printer_discovery_service.dart';
import 'scan_screen.dart';

class PrinterScanScreen extends StatefulWidget {
  const PrinterScanScreen({super.key});

  static const Color moduleColor = Color(0xFF0EA5E9);

  @override
  State<PrinterScanScreen> createState() => _PrinterScanScreenState();
}

class _PrinterScanScreenState extends State<PrinterScanScreen> {
  List<PrinterDevice> _printers = [];
  PrinterDevice? _connectedPrinter;
  bool _isScanning = false;
  bool _isConnecting = false;
  String _loadingMsg = 'Scanning network…';
  final _manualIpController = TextEditingController();

  @override
  void dispose() {
    _manualIpController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _discoverPrinters();
  }

  Future<void> _discoverPrinters() async {
    setState(() { _isScanning = true; _loadingMsg = 'Scanning network for printers…'; });
    try {
      final found = await PrinterDiscoveryService.discoverPrinters();
      if (mounted) setState(() { _printers = found; _isScanning = false; });
    } catch (e) {
      if (mounted) setState(() => _isScanning = false);
    }
  }

  Future<void> _connectPrinter(PrinterDevice printer) async {
    setState(() { _isConnecting = true; _loadingMsg = 'Connecting to ${printer.name}…'; });
    try {
      // Real TCP check on IPP port 631
      final socket = await Socket.connect(
        printer.address,
        631,
        timeout: const Duration(seconds: 5),
      );
      await socket.close();
      printer.status = PrinterStatus.connected;
      if (mounted) {
        setState(() { _connectedPrinter = printer; _isConnecting = false; });
        _showSnack('✅  Connected to ${printer.name}');
      }
    } catch (e) {
      printer.status = PrinterStatus.error;
      if (mounted) {
        setState(() => _isConnecting = false);
        _showSnack('Connection failed: Printer unreachable at ${printer.address}', isError: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: _isScanning || _isConnecting,
      message: _loadingMsg,
      child: Scaffold(
        backgroundColor: AppTheme.surface,
        appBar: AppBar(
          title: const Text('Printer Scan'),
          leading: const BackButton(),
          actions: [
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: _discoverPrinters,
              tooltip: 'Refresh',
            ),
          ],
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHero(),
                const SizedBox(height: 24),
                if (_connectedPrinter != null) ...[
                  _buildConnectedBanner(),
                  const SizedBox(height: 20),
                ],
                _buildPrinterList(),
                const SizedBox(height: 20),
                _buildManualConnect(),
                const SizedBox(height: 16),
                _buildInfoBox(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHero() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0EA5E9), Color(0xFF0369A1)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          const Icon(Icons.document_scanner_outlined,
              color: Colors.white, size: 44),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Printer Scan',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(
                  'Scan documents from WiFi printer to PDF',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.85), fontSize: 13),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildConnectedBanner() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.success.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.success.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.check_circle, color: AppTheme.success, size: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Printer Connected',
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: AppTheme.success,
                        fontSize: 14)),
                Text(_connectedPrinter!.name,
                    style: const TextStyle(
                        fontSize: 13, color: AppTheme.textSecondary)),
              ],
            ),
          ),
          ElevatedButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    ScanScreen(printer: _connectedPrinter!),
              ),
            ),
            icon: const Icon(Icons.document_scanner, size: 18),
            label: const Text('Start Scan'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.success,
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrinterList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Available Printers',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary)),
            if (_isScanning)
              const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: PrinterScanScreen.moduleColor),
              ),
          ],
        ),
        const SizedBox(height: 4),
        const Text('Printers found on your WiFi network',
            style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
        const SizedBox(height: 12),
        if (_printers.isEmpty && !_isScanning)
          _buildNoPrintersFound()
        else
          ..._printers.map((p) => _PrinterTile(
                printer: p,
                isConnected: _connectedPrinter?.id == p.id,
                onConnect: () => _connectPrinter(p),
                onScan: _connectedPrinter?.id == p.id
                    ? () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => ScanScreen(printer: p)),
                        )
                    : null,
              )),
      ],
    );
  }

  Widget _buildNoPrintersFound() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        children: [
          Icon(Icons.print_disabled_outlined,
              size: 40, color: AppTheme.textSecondary.withOpacity(0.5)),
          const SizedBox(height: 12),
          const Text('No printers found',
              style: TextStyle(
                  fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
          const SizedBox(height: 6),
          const Text(
            'Make sure your printer is on the same WiFi network and scanning is enabled.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: _discoverPrinters,
            icon: const Icon(Icons.refresh, size: 18),
            label: const Text('Scan Again'),
            style: ElevatedButton.styleFrom(
                backgroundColor: PrinterScanScreen.moduleColor),
          ),
        ],
      ),
    );
  }

  Widget _buildManualConnect() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Manual Connect',
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary)),
          const SizedBox(height: 4),
          const Text('Enter printer IP address manually',
              style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _manualIpController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    hintText: '192.168.1.100',
                    hintStyle:
                        const TextStyle(color: AppTheme.textSecondary),
                    filled: true,
                    fillColor: AppTheme.surface,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: AppTheme.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: AppTheme.border),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 12),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton(
                onPressed: () {
                  final ip = _manualIpController.text.trim();
                  if (ip.isEmpty) return;
                  final manual = PrinterDevice(
                    id: 'manual_$ip',
                    name: 'Printer ($ip)',
                    address: ip,
                    type: PrinterConnectionType.wifi,
                  );
                  setState(() => _printers.insert(0, manual));
                  _connectPrinter(manual);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: PrinterScanScreen.moduleColor,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 14),
                ),
                child: const Text('Connect'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoBox() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: PrinterScanScreen.moduleColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: PrinterScanScreen.moduleColor.withOpacity(0.2)),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.info_outline,
                  size: 16, color: PrinterScanScreen.moduleColor),
              SizedBox(width: 8),
              Text('Requirements',
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                      color: PrinterScanScreen.moduleColor)),
            ],
          ),
          SizedBox(height: 8),
          Text('• Printer must support eSCL / AirScan / Mopria Scan',
              style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
          SizedBox(height: 3),
          Text('• Phone and printer must be on same WiFi network',
              style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
          SizedBox(height: 3),
          Text('• Compatible: HP, Canon, Epson, Brother (most models after 2015)',
              style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
          SizedBox(height: 3),
          Text('• Bluetooth scan requires printer app (use manual IP instead)',
              style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
        ],
      ),
    );
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? AppTheme.error : AppTheme.success,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }
}

// ── Printer Tile Widget ──────────────────────────────────────────────────────

class _PrinterTile extends StatelessWidget {
  final PrinterDevice printer;
  final bool isConnected;
  final VoidCallback onConnect;
  final VoidCallback? onScan;

  const _PrinterTile({
    required this.printer,
    required this.isConnected,
    required this.onConnect,
    this.onScan,
  });

  @override
  Widget build(BuildContext context) {
    const moduleColor = PrinterScanScreen.moduleColor;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isConnected
              ? AppTheme.success.withOpacity(0.4)
              : AppTheme.border,
          width: isConnected ? 1.5 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: isConnected
                  ? AppTheme.success.withOpacity(0.1)
                  : moduleColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              printer.type == PrinterConnectionType.wifi
                  ? Icons.wifi
                  : Icons.bluetooth,
              color: isConnected ? AppTheme.success : moduleColor,
              size: 22,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(printer.name,
                    style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.textPrimary)),
                Row(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 3),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: isConnected
                            ? AppTheme.success.withOpacity(0.1)
                            : AppTheme.border.withOpacity(0.5),
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Text(
                        '${printer.typeLabel}  •  ${printer.statusLabel}',
                        style: TextStyle(
                          fontSize: 11,
                          color: isConnected
                              ? AppTheme.success
                              : AppTheme.textSecondary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          isConnected
              ? ElevatedButton.icon(
                  onPressed: onScan,
                  icon: const Icon(Icons.document_scanner, size: 16),
                  label: const Text('Scan'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.success,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    textStyle: const TextStyle(fontSize: 13),
                  ),
                )
              : OutlinedButton(
                  onPressed: onConnect,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: moduleColor,
                    side: const BorderSide(color: moduleColor),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    textStyle: const TextStyle(fontSize: 13),
                  ),
                  child: const Text('Connect'),
                ),
        ],
      ),
    );
  }
}

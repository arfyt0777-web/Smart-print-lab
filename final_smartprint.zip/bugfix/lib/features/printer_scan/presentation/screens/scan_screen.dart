import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../shared/widgets/loading_overlay.dart';
import '../../data/printer_scan_models.dart';
import '../../data/printer_discovery_service.dart';
import '../../data/scan_pdf_service.dart';

class ScanScreen extends StatefulWidget {
  final PrinterDevice printer;
  const ScanScreen({super.key, required this.printer});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  static const moduleColor = Color(0xFF0EA5E9);
  final List<ScannedPage> _pages = [];
  bool _isScanning = false;
  bool _isExporting = false;
  String _loadingMsg = 'Scanning...';
  String _selectedColorMode = 'RGB24';
  int _selectedDpi = 300;
  bool _autoEnhance = true;
  ScanSizePreset _selectedSizePreset = ScanSizePreset.presetOriginal;
  late final ScanService _scanService;

  @override
  void initState() {
    super.initState();
    _scanService = ScanService(widget.printer);
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: _isScanning || _isExporting,
      message: _loadingMsg,
      child: Scaffold(
        backgroundColor: AppTheme.surface,
        appBar: AppBar(title: Text('Scan - ${widget.printer.name}')),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSettings(),
                const SizedBox(height: 20),
                _buildScanButton(),
                const SizedBox(height: 20),
                if (_pages.isNotEmpty) ...[
                  _buildPageList(),
                  const SizedBox(height: 20),
                  _buildExportSection(),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSettings() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppTheme.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Scan Settings',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Color Mode', style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
              DropdownButton<String>(
                value: _selectedColorMode, underline: const SizedBox(),
                style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13, fontWeight: FontWeight.w600),
                items: const [
                  DropdownMenuItem(value: 'RGB24', child: Text('Color')),
                  DropdownMenuItem(value: 'Grayscale8', child: Text('Grayscale')),
                ],
                onChanged: (v) => setState(() => _selectedColorMode = v ?? 'RGB24'),
              ),
            ],
          ),
          const Divider(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Resolution', style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
              DropdownButton<int>(
                value: _selectedDpi, underline: const SizedBox(),
                style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13, fontWeight: FontWeight.w600),
                items: const [
                  DropdownMenuItem(value: 150, child: Text('150 DPI')),
                  DropdownMenuItem(value: 300, child: Text('300 DPI')),
                  DropdownMenuItem(value: 600, child: Text('600 DPI')),
                ],
                onChanged: (v) => setState(() => _selectedDpi = v ?? 300),
              ),
            ],
          ),
          const Divider(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Output Size', style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
              DropdownButton<ScanSizePreset>(
                value: _selectedSizePreset, underline: const SizedBox(),
                style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13, fontWeight: FontWeight.w600),
                items: ScanSizePreset.all.map((p) =>
                  DropdownMenuItem(value: p, child: Text(p.label))).toList(),
                onChanged: (v) => setState(() => _selectedSizePreset = v ?? ScanSizePreset.presetOriginal),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildScanButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: _scanPage,
        icon: const Icon(Icons.document_scanner_outlined),
        label: Text(_pages.isEmpty ? 'Scan Page' : 'Scan Next Page'),
        style: ElevatedButton.styleFrom(
            backgroundColor: moduleColor, padding: const EdgeInsets.symmetric(vertical: 16)),
      ),
    );
  }

  Widget _buildPageList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Scanned Pages (${_pages.length})',
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
        const SizedBox(height: 12),
        SizedBox(
          height: 180,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: _pages.length,
            itemBuilder: (context, index) => Container(
              margin: const EdgeInsets.only(right: 12),
              width: 130,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppTheme.border)),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(9),
                child: Image.memory(_pages[index].imageBytes, width: 130, height: 180, fit: BoxFit.cover),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildExportSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Export',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: _ExportBtn(icon: Icons.picture_as_pdf_outlined, label: 'Save PDF',
                sublabel: '${_pages.length} page(s)', color: AppTheme.error, onTap: _savePdf)),
            const SizedBox(width: 10),
            Expanded(child: _ExportBtn(icon: Icons.print_outlined, label: 'Print',
                sublabel: 'WiFi / BT', color: AppTheme.primary, onTap: _printPages)),
          ],
        ),
        const SizedBox(height: 10),
        SizedBox(width: double.infinity,
          child: _ExportBtn(icon: Icons.save_alt_outlined, label: 'Save Images to Phone',
              sublabel: 'High quality JPG', color: AppTheme.success, onTap: _saveToPhone)),
        const SizedBox(height: 24),
      ],
    );
  }

  Future<void> _scanPage() async {
    // Guard: verify printer is still reachable before scanning
    if (widget.printer.status != PrinterStatus.connected) {
      _showSnack('Printer not connected. Please reconnect first.', isError: true);
      return;
    }
    try {
      final socket = await Socket.connect(
        widget.printer.address,
        631,
        timeout: const Duration(seconds: 4),
      );
      await socket.close();
    } catch (_) {
      widget.printer.status = PrinterStatus.error;
      if (mounted) _showSnack('Printer unreachable. Please reconnect.', isError: true);
      return;
    }

    setState(() { _isScanning = true; _loadingMsg = 'Scanning page ${_pages.length + 1}...'; });
    try {
      Uint8List bytes = await _scanService.scanPage(colorMode: _selectedColorMode, resolutionDpi: _selectedDpi);
      if (_autoEnhance) bytes = ScanPdfService.enhanceScan(bytes);
      final page = ScannedPage(imageBytes: bytes, pageNumber: _pages.length + 1, scannedAt: DateTime.now());
      if (mounted) { setState(() => _pages.add(page)); _showSnack('✅ Page ${page.pageNumber} scanned!'); }
    } catch (e) {
      if (mounted) _showSnack('Scan failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isScanning = false);
    }
  }

  Future<void> _savePdf() async {
    if (_pages.isEmpty) return;
    setState(() { _isExporting = true; _loadingMsg = 'Generating PDF...'; });
    try {
      final file = await ScanPdfService.generatePdf(
        _pages,
        dpi: _selectedDpi,
        sizePreset: _selectedSizePreset,
      );
      await Printing.sharePdf(bytes: await file.readAsBytes(), filename: file.path.split('/').last);
    } catch (e) {
      if (mounted) _showSnack('PDF failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _printPages() async {
    if (_pages.isEmpty) return;
    setState(() { _isExporting = true; _loadingMsg = 'Preparing print...'; });
    try {
      final file = await ScanPdfService.generatePdf(_pages, dpi: _selectedDpi);
      await Printing.layoutPdf(onLayout: (_) async => await file.readAsBytes(), name: 'Scanned Document');
    } catch (e) {
      if (mounted) _showSnack('Print failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _saveToPhone() async {
    if (_pages.isEmpty) return;
    setState(() { _isExporting = true; _loadingMsg = 'Saving images...'; });
    try {
      final files = await ScanPdfService.saveAsJpg(
        _pages,
        sizePreset: _selectedSizePreset,
      );
      if (mounted) _showSnack('✅ ${files.length} page(s) saved as JPG!');
    } catch (e) {
      if (mounted) _showSnack('Save failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? AppTheme.error : AppTheme.success,
      behavior: SnackBarBehavior.floating,
    ));
  }
}

class _ExportBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final String sublabel;
  final Color color;
  final VoidCallback onTap;
  const _ExportBtn({required this.icon, required this.label, required this.sublabel, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.06),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.25), width: 1.5),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: color)),
                Text(sublabel, style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

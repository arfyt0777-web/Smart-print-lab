import 'dart:io';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import 'package:image/image.dart' as img;
import '../../../core/config/app_config.dart';
import '../../../shared/utils/image_compress_util.dart';

/// Background removal via remove.bg API ONLY.
/// Compresses input image before upload to prevent OOM and slow uploads.
class BackgroundRemovalService {
  static const int _timeoutSeconds = 30;

  static Future<Uint8List> removeBackground(
    File imageFile, {
    void Function(String)? onStatusUpdate,
  }) async {
    final keys = AppConfig.removeBgApiKeys;

    if (keys.isEmpty) {
      throw Exception(
        'No remove.bg API key configured.\n'
        'Add REMOVE_BG_API_KEY in Codemagic environment variables.',
      );
    }

    // Compress before upload — prevents OOM on 8–20MB camera images
    onStatusUpdate?.call('Compressing image…');
    final rawBytes = await imageFile.readAsBytes();
    final compressedBytes = await ImageCompressUtil.compressInputImage(rawBytes);

    onStatusUpdate?.call('Removing background with AI…');

    final dio = Dio(BaseOptions(
      connectTimeout: const Duration(seconds: _timeoutSeconds),
      receiveTimeout: const Duration(seconds: _timeoutSeconds),
      responseType: ResponseType.bytes,
    ));

    String? lastError;

    try {
      for (final key in keys) {
        if (key.trim().length < 10) continue;

        try {
          final formData = FormData.fromMap({
            'image_file': MultipartFile.fromBytes(
              compressedBytes,
              filename: 'photo.jpg',
              contentType: DioMediaType.parse('image/jpeg'),
            ),
            'size': 'auto',
          });

          final response = await dio.post(
            '${AppConfig.removeBgBaseUrl}/removebg',
            data: formData,
            options: Options(headers: {'X-Api-Key': key}),
          );

          if (response.statusCode != 200) {
            lastError = 'API returned status ${response.statusCode}';
            continue;
          }

          final data = response.data;
          if (data == null) {
            lastError = 'API returned empty response';
            continue;
          }

          final bytes = Uint8List.fromList(data as List<int>);

          // Strict validation 1: must be > 50KB (real background-removed image)
          if (bytes.length < 50000) {
            lastError = 'API returned suspiciously small image (${bytes.length} bytes — expected >50KB)';
            continue;
          }

          // Strict validation 2: must be valid PNG or JPEG by magic bytes
          final isPng = bytes[0] == 0x89 && bytes[1] == 0x50 && bytes[2] == 0x4E && bytes[3] == 0x47;
          final isJpg = bytes[0] == 0xFF && bytes[1] == 0xD8;
          if (!isPng && !isJpg) {
            lastError = 'API returned invalid image format (not PNG/JPG)';
            continue;
          }

          // Strict validation 3: must actually decode as a real image
          final decoded = img.decodeImage(bytes);
          if (decoded == null) {
            lastError = 'API response failed image decode — corrupted data';
            continue;
          }

          return bytes;

        } on DioException catch (e) {
          final status = e.response?.statusCode;
          if (status == 402) { lastError = 'Credits exhausted (402)'; continue; }
          if (status == 403) { lastError = 'Invalid API key (403)'; continue; }
          if (status == 429) { lastError = 'Rate limited (429)'; continue; }
          lastError = e.message ?? 'Network error: ${e.type}';
          continue;
        }
      }
    } finally {
      dio.close();
    }

    throw Exception(
      'Background removal failed.\n'
      'Reason: ${lastError ?? 'All API keys failed'}\n\n'
      'Please check:\n'
      '• Internet connection is active\n'
      '• API keys are valid in Codemagic settings\n'
      '• remove.bg account has credits',
    );
  }
}

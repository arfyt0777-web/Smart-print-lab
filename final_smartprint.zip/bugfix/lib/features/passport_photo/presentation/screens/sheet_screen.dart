import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../shared/widgets/loading_overlay.dart';
import '../../data/sheet_generator_service.dart';
import '../../data/pdf_export_service.dart';

class SheetScreen extends StatefulWidget {
  final Uint8List? processedPng;   // null when using original
  final Color bgColor;
  final File? originalFile;        // non-null when keeping original background
  const SheetScreen({super.key, required this.processedPng, required this.bgColor, this.originalFile});

  @override
  State<SheetScreen> createState() => _SheetScreenState();
}

class _SheetScreenState extends State<SheetScreen> {
  int _photoCount = 4;
  int _borderPx = 0;           // border thickness in pixels on sheet
  Uint8List? _sheetPng;
  bool _isGenerating = false;
  bool _isExporting = false;
  String _loadingMessage = 'Generating sheet...';
  final List<int> _countOptions = [2, 4, 6, 8, 10, 12];
  final _manualCountCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _generateSheet();
  }

  @override
  void dispose() {
    _manualCountCtrl.dispose();
    super.dispose();
  }

  Future<Uint8List> _getSubjectPng() async {
    if (widget.processedPng != null) return widget.processedPng!;
    // Original file — encode as PNG with opaque background
    final bytes = await widget.originalFile!.readAsBytes();
    final decoded = img.decodeImage(bytes);
    if (decoded == null) throw Exception('Cannot decode image');
    return Uint8List.fromList(img.encodePng(decoded));
  }

  Future<void> _generateSheet() async {
    setState(() { _isGenerating = true; _loadingMessage = 'Generating sheet...'; });
    try {
      final subjectPng = await _getSubjectPng();
      final sheet = await SheetGeneratorService.generateSheet(
        subjectPng: subjectPng,
        bgColor: widget.bgColor,
        photoCount: _photoCount,
        borderPx: _borderPx,
        useOriginalBg: widget.originalFile != null,
      );
      if (mounted) setState(() { _sheetPng = sheet; _isGenerating = false; });
    } catch (e) {
      if (mounted) { setState(() => _isGenerating = false); _showSnack('Failed: $e', isError: true); }
    }
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: _isGenerating || _isExporting,
      message: _loadingMessage,
      child: Scaffold(
        backgroundColor: AppTheme.surface,
        appBar: AppBar(title: const Text('Print Sheet')),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildCountSelector(),
                const SizedBox(height: 20),
                _buildBorderSelector(),
                const SizedBox(height: 20),
                _buildSheetPreview(),
                const SizedBox(height: 24),
                _buildExportSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCountSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Number of Photos', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
        const SizedBox(height: 12),
        Wrap(
          spacing: 10, runSpacing: 10,
          children: [
            ..._countOptions.map((n) {
              final selected = n == _photoCount;
              return GestureDetector(
                onTap: () { if (!selected) { setState(() => _photoCount = n); _generateSheet(); } },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 54, height: 54,
                  decoration: BoxDecoration(
                    color: selected ? AppTheme.primary : Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: selected ? AppTheme.primary : AppTheme.border, width: 1.5),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text('$n', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: selected ? Colors.white : AppTheme.textPrimary)),
                    Text('photos', style: TextStyle(fontSize: 9, color: selected ? Colors.white.withOpacity(0.8) : AppTheme.textSecondary)),
                  ]),
                ),
              );
            }),
            // Manual count input
            SizedBox(
              width: 70, height: 54,
              child: TextField(
                controller: _manualCountCtrl,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  hintText: 'Own',
                  hintStyle: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppTheme.border)),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppTheme.border)),
                ),
                onSubmitted: (v) {
                  final n = int.tryParse(v);
                  if (n != null && n > 0 && n <= 30) {
                    setState(() => _photoCount = n);
                    _generateSheet();
                  }
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildBorderSelector() {
    final options = [0, 4, 8, 16];
    final labels = ['None', 'Thin', 'Medium', 'Thick'];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Border Size', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
        const SizedBox(height: 10),
        Row(
          children: List.generate(options.length, (i) {
            final sel = options[i] == _borderPx;
            return Expanded(child: Padding(
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(
                onTap: () { setState(() => _borderPx = options[i]); _generateSheet(); },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: sel ? AppTheme.primary : Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: sel ? AppTheme.primary : AppTheme.border),
                  ),
                  child: Text(labels[i], textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
                          color: sel ? Colors.white : AppTheme.textPrimary)),
                ),
              ),
            ));
          }),
        ),
      ],
    );
  }

  Widget _buildSheetPreview() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Sheet Preview', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(16), border: Border.all(color: AppTheme.border)),
          child: AspectRatio(
            aspectRatio: 4 / 6,
            child: _sheetPng != null
                ? ClipRRect(borderRadius: BorderRadius.circular(15), child: Image.memory(_sheetPng!, fit: BoxFit.cover))
                : const Center(child: CircularProgressIndicator(color: AppTheme.primary)),
          ),
        ),
      ],
    );
  }

  Widget _buildExportSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Export & Print', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _ExportButton(icon: Icons.print_outlined, label: 'Print', sublabel: 'WiFi / BT', color: AppTheme.primary, onTap: _printSheet)),
          const SizedBox(width: 10),
          Expanded(child: _ExportButton(icon: Icons.picture_as_pdf_outlined, label: 'Save PDF', sublabel: 'Print-ready PDF', color: AppTheme.error, onTap: _downloadAsPdf)),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: _ExportButton(icon: Icons.image_outlined, label: 'Save JPG', sublabel: 'JPEG format', color: const Color(0xFF0EA5E9), onTap: _saveAsJpg)),
          const SizedBox(width: 10),
          Expanded(child: _ExportButton(icon: Icons.photo_outlined, label: 'Save PNG', sublabel: 'PNG format', color: const Color(0xFF7C3AED), onTap: _saveAsPng)),
        ]),
        const SizedBox(height: 10),
        SizedBox(width: double.infinity,
          child: _ExportButton(icon: Icons.photo_library_outlined, label: 'Save to Gallery', sublabel: 'Visible in Photos app', color: AppTheme.success, onTap: _saveToGallery)),
        const SizedBox(height: 24),
      ],
    );
  }

  Future<void> _printSheet() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMessage = 'Preparing print...'; });
    try {
      final pdf = await PdfExportService.generatePdf(_sheetPng!);
      await Printing.layoutPdf(onLayout: (_) async => pdf.readAsBytesSync(), name: 'Passport Sheet');
    } catch (e) { if (mounted) _showSnack('Print failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  Future<void> _downloadAsPdf() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMessage = 'Generating PDF...'; });
    try {
      final pdf = await PdfExportService.generatePdf(_sheetPng!);
      await Printing.sharePdf(bytes: pdf.readAsBytesSync(), filename: 'passport_sheet.pdf');
    } catch (e) { if (mounted) _showSnack('PDF failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  Future<void> _saveAsJpg() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMessage = 'Saving JPG...'; });
    try {
      final decoded2 = img.decodeImage(_sheetPng!);
      if (decoded2 == null) throw Exception('Decode failed');
      final jpgBytes = Uint8List.fromList(img.encodeJpg(decoded2, quality: 95));
      final dir = await getExternalStorageDirectory() ?? await getTemporaryDirectory();
      final file = File('${dir.path}/smartprint_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await file.writeAsBytes(jpgBytes);
      if (mounted) _showSnack('✅ Saved as JPG: ${file.path}');
    } catch (e) { if (mounted) _showSnack('Save failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  Future<void> _saveAsPng() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMessage = 'Saving PNG...'; });
    try {
      final dir = await getExternalStorageDirectory() ?? await getTemporaryDirectory();
      final file = File('${dir.path}/smartprint_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_sheetPng!);
      if (mounted) _showSnack('✅ Saved as PNG: ${file.path}');
    } catch (e) { if (mounted) _showSnack('Save failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  Future<void> _saveToGallery() async {
    if (_sheetPng == null) return;
    setState(() { _isExporting = true; _loadingMessage = 'Saving to gallery...'; });
    try {
      // Save to DCIM/SmartPrint so it appears in gallery
      final dir = Directory('/storage/emulated/0/DCIM/SmartPrint');
      if (!await dir.exists()) await dir.create(recursive: true);
      final file = File('${dir.path}/passport_${DateTime.now().millisecondsSinceEpoch}.jpg');
      final decoded3 = img.decodeImage(_sheetPng!);
      if (decoded3 == null) throw Exception('Decode failed');
      final jpgBytes = Uint8List.fromList(img.encodeJpg(decoded3, quality: 95));
      await file.writeAsBytes(jpgBytes);
      if (mounted) _showSnack('✅ Saved to Gallery (DCIM/SmartPrint)');
    } catch (e) { if (mounted) _showSnack('Gallery save failed: $e', isError: true); }
    finally { if (mounted) setState(() => _isExporting = false); }
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? AppTheme.error : AppTheme.success,
      behavior: SnackBarBehavior.floating,
    ));
  }
}

class _ExportButton extends StatelessWidget {
  final IconData icon; final String label, sublabel; final Color color; final VoidCallback onTap;
  const _ExportButton({required this.icon, required this.label, required this.sublabel, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      decoration: BoxDecoration(color: color.withOpacity(0.06), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(0.25), width: 1.5)),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(width: 8),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: color)),
          Text(sublabel, style: const TextStyle(fontSize: 10, color: AppTheme.textSecondary)),
        ]),
      ]),
    ),
  );
}


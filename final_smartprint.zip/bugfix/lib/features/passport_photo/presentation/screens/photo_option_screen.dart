import 'dart:io';
import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';
import 'background_screen.dart';
import 'sheet_screen.dart';

/// Shown after image is picked — user chooses:
/// 1) Keep original background → go to SheetScreen directly
/// 2) Remove background with AI → go to BackgroundScreen
class PhotoOptionScreen extends StatelessWidget {
  final File imageFile;
  const PhotoOptionScreen({super.key, required this.imageFile});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surface,
      appBar: AppBar(title: const Text('Choose Option')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 16),
              // Photo preview
              Center(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.file(imageFile,
                      width: 220, height: 280, fit: BoxFit.cover),
                ),
              ),
              const SizedBox(height: 32),
              const Text('What would you like to do?',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.textPrimary)),
              const SizedBox(height: 8),
              const Text('Choose how to process your photo',
                  style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
              const SizedBox(height: 32),
              // Option 1 — Keep original
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (_) => SheetScreen(
                        processedPng: null,
                        bgColor: Colors.white,
                        originalFile: imageFile,
                      ),
                    ),
                  ),
                  icon: const Icon(Icons.image_outlined),
                  label: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Continue with Original',
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                      Text('Keep existing background',
                          style: TextStyle(fontSize: 11, fontWeight: FontWeight.w400)),
                    ],
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.success,
                    padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
                    alignment: Alignment.centerLeft,
                  ),
                ),
              ),
              const SizedBox(height: 14),
              // Option 2 — Remove background
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (_) => BackgroundScreen(imageFile: imageFile),
                    ),
                  ),
                  icon: const Icon(Icons.auto_fix_high_outlined),
                  label: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Remove Background & Continue',
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                      Text('AI removes background automatically',
                          style: TextStyle(fontSize: 11, fontWeight: FontWeight.w400)),
                    ],
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primary,
                    padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
                    alignment: Alignment.centerLeft,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

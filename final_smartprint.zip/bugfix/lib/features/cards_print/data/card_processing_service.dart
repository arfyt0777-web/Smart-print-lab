import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;
import 'card_type_model.dart';

class CardProcessingService {
  // Sheet: 4x6 inch @ 300 DPI
  static const int sheetW = 1200;
  static const int sheetH = 1800;
  static const int sheetPadding = 40;
  static const int cardSpacing = 30;

  /// Auto-crop card from image using edge detection.
  /// Returns JPEG bytes of the cropped card at original quality.
  static Future<Uint8List> cropCard(File imageFile) async {
    final bytes = await imageFile.readAsBytes();
    img.Image? original = img.decodeImage(bytes);
    if (original == null) throw Exception('Cannot decode image');

    // Auto-detect card region via edge/contrast analysis
    final cropped = _autoCropCard(original);

    // Auto-enhance: adjust brightness + contrast
    final enhanced = _enhanceCard(cropped);

    return Uint8List.fromList(img.encodeJpg(enhanced, quality: 100));
  }

  /// Crop card from PDF page image bytes (already rasterized).
  static Future<Uint8List> cropCardFromBytes(Uint8List bytes) async {
    img.Image? original = img.decodeImage(bytes);
    if (original == null) throw Exception('Cannot decode image');
    final cropped = _autoCropCard(original);
    final enhanced = _enhanceCard(cropped);
    return Uint8List.fromList(img.encodeJpg(enhanced, quality: 100));
  }

  /// Generate a 4x6 print sheet with all card images.
  /// Cards arranged 2 per row.
  static Future<Uint8List> generateCardSheet(
      List<Uint8List> cardImages, CardTypeModel cardType) async {
    final args = _CardSheetArgs(
      cardImages: cardImages,
      cardW: cardType.widthPx,
      cardH: cardType.heightPx,
      sheetW: sheetW,
      sheetH: sheetH,
      spacing: cardSpacing,
    );
    return compute(_generateCardSheetIsolate, args);
  }

  static Uint8List _generateCardSheetIsolate(_CardSheetArgs a) {
    final sheet = img.Image(width: a.sheetW, height: a.sheetH, numChannels: 3);
    img.fill(sheet, color: img.ColorRgb8(255, 255, 255));

    const cols = 2;
    final rows = (a.cardImages.length / cols).ceil();

    final totalW = cols * a.cardW + (cols - 1) * a.spacing;
    final totalH = rows * a.cardH + (rows - 1) * a.spacing;
    final startX = ((a.sheetW - totalW) / 2).round();
    final startY = ((a.sheetH - totalH) / 2).round();

    for (int i = 0; i < a.cardImages.length; i++) {
      final col = i % cols;
      final row = i ~/ cols;

      img.Image? cardImg = img.decodeImage(a.cardImages[i]);
      if (cardImg == null) continue;

      final fitted = _fitContain(cardImg, a.cardW, a.cardH);

      final x = startX + col * (a.cardW + a.spacing);
      final y = startY + row * (a.cardH + a.spacing);

      _drawCardBorder(sheet, x - 1, y - 1, a.cardW + 2, a.cardH + 2);
      img.compositeImage(sheet, fitted, dstX: x, dstY: y);
    }

    return Uint8List.fromList(img.encodePng(sheet));
  }

  // ── Private helpers ────────────────────────────────────────────────

  /// Auto-crop: finds content boundaries using fast edge scan on downsampled image.
  static img.Image _autoCropCard(img.Image src) {
    final w = src.width;
    final h = src.height;

    // Downsample 4x for fast edge scan
    final scale = 4;
    final small = img.copyResize(src, width: w ~/ scale, height: h ~/ scale,
        interpolation: img.Interpolation.average);
    final gray = img.grayscale(small);
    final sw = small.width;
    final sh = small.height;

    int top = 0;
    outer: for (int y = 0; y < sh; y++) {
      for (int x = 0; x < sw; x++) {
        if (gray.getPixel(x, y).r < 240) { top = y; break outer; }
      }
    }
    int bottom = sh - 1;
    outer: for (int y = sh - 1; y >= 0; y--) {
      for (int x = 0; x < sw; x++) {
        if (gray.getPixel(x, y).r < 240) { bottom = y; break outer; }
      }
    }
    int left = 0;
    outer: for (int x = 0; x < sw; x++) {
      for (int y = 0; y < sh; y++) {
        if (gray.getPixel(x, y).r < 240) { left = x; break outer; }
      }
    }
    int right = sw - 1;
    outer: for (int x = sw - 1; x >= 0; x--) {
      for (int y = 0; y < sh; y++) {
        if (gray.getPixel(x, y).r < 240) { right = x; break outer; }
      }
    }

    // Scale coordinates back to original + padding
    const pad = 8;
    final t = ((top    * scale) - pad).clamp(0, h - 1);
    final b = ((bottom * scale) + pad).clamp(0, h - 1);
    final l = ((left   * scale) - pad).clamp(0, w - 1);
    final r = ((right  * scale) + pad).clamp(0, w - 1);

    final cropW = r - l;
    final cropH = b - t;
    if (cropW < 50 || cropH < 50) return src;

    return img.copyCrop(src, x: l, y: t, width: cropW, height: cropH);
  }

  /// Auto-enhance: slightly boost contrast and brightness.
  static img.Image _enhanceCard(img.Image src) {
    // Adjust levels: slight contrast boost
    return img.adjustColor(
      src,
      contrast: 1.1,
      brightness: 1.05,
      saturation: 1.05,
    );
  }

  /// Resizes [src] to fit inside [targetW]x[targetH] preserving aspect ratio.
  /// Remaining space filled with white. Never stretches.
  static img.Image _fitContain(img.Image src, int targetW, int targetH) {
    final scaleW = targetW / src.width;
    final scaleH = targetH / src.height;
    final scale = scaleW < scaleH ? scaleW : scaleH;

    final fitW = (src.width * scale).round();
    final fitH = (src.height * scale).round();

    final scaled = img.copyResize(
      src,
      width: fitW,
      height: fitH,
      interpolation: img.Interpolation.linear,
    );

    // Create white canvas of exact target size
    final canvas = img.Image(width: targetW, height: targetH, numChannels: 3);
    img.fill(canvas, color: img.ColorRgb8(255, 255, 255));

    // Center the scaled image on the canvas
    final offsetX = ((targetW - fitW) / 2).round();
    final offsetY = ((targetH - fitH) / 2).round();
    img.compositeImage(canvas, scaled, dstX: offsetX, dstY: offsetY);

    return canvas;
  }

  /// Draw a light grey 1px border around a card.
  static void _drawCardBorder(
      img.Image sheet, int x, int y, int w, int h) {
    final borderColor = img.ColorRgb8(200, 200, 200);
    for (int i = x; i < x + w; i++) {
      if (i >= 0 && i < sheet.width) {
        if (y >= 0 && y < sheet.height) sheet.setPixel(i, y, borderColor);
        if (y + h - 1 >= 0 && y + h - 1 < sheet.height)
          sheet.setPixel(i, y + h - 1, borderColor);
      }
    }
    for (int j = y; j < y + h; j++) {
      if (j >= 0 && j < sheet.height) {
        if (x >= 0 && x < sheet.width) sheet.setPixel(x, j, borderColor);
        if (x + w - 1 >= 0 && x + w - 1 < sheet.width)
          sheet.setPixel(x + w - 1, j, borderColor);
      }
    }
  }
}

class _CardSheetArgs {
  final List<Uint8List> cardImages;
  final int cardW, cardH, sheetW, sheetH, spacing;
  const _CardSheetArgs({
    required this.cardImages,
    required this.cardW, required this.cardH,
    required this.sheetW, required this.sheetH,
    required this.spacing,
  });
}

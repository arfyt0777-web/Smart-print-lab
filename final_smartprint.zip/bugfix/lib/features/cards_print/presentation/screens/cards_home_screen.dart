import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';
import 'id_front_back_screen.dart';

class CardsHomeScreen extends StatelessWidget {
  const CardsHomeScreen({super.key});

  static const Color moduleColor = Color(0xFF7C3AED);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surface,
      appBar: AppBar(
        title: const Text('Cards Print'),
        leading: const BackButton(),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHero(),
              const SizedBox(height: 28),
              GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const IdFrontBackScreen())),
                child: Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF0EA5E9).withOpacity(0.35), width: 1.5),
                    boxShadow: [BoxShadow(color: const Color(0xFF0EA5E9).withOpacity(0.07), blurRadius: 12, offset: const Offset(0, 3))],
                  ),
                  child: Row(children: [
                    Container(
                      width: 50, height: 50,
                      decoration: BoxDecoration(color: const Color(0xFF0EA5E9).withOpacity(0.1), borderRadius: BorderRadius.circular(13)),
                      child: const Icon(Icons.flip_outlined, color: Color(0xFF0EA5E9), size: 26),
                    ),
                    const SizedBox(width: 14),
                    const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('ID Card Front & Back', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
                      SizedBox(height: 3),
                      Text('Front on top, Back below — A4 sheet', style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
                    ])),
                    const Icon(Icons.arrow_forward_ios, size: 14, color: Color(0xFF0EA5E9)),
                  ]),
                ),
              ),
              const SizedBox(height: 20),
              _buildInfoBox(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHero() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF7C3AED), Color(0xFF5B21B6)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          const Icon(Icons.credit_card, color: Colors.white, size: 44),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Cards Print', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text('Print ID cards on A4 sheet', style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 13)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoBox() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: moduleColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: moduleColor.withOpacity(0.2)),
      ),
      child: const Row(
        children: [
          Icon(Icons.info_outline, size: 18, color: Color(0xFF7C3AED)),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'Upload front and back of your ID card to generate a print-ready A4 sheet.',
              style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
            ),
          ),
        ],
      ),
    );
  }
}

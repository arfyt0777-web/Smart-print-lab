import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../shared/widgets/loading_overlay.dart';
import '../../data/card_type_model.dart';
import '../../data/card_processing_service.dart';
import 'card_preview_screen.dart';

class CardCaptureScreen extends StatefulWidget {
  final CardTypeModel cardType;
  const CardCaptureScreen({super.key, required this.cardType});

  @override
  State<CardCaptureScreen> createState() => _CardCaptureScreenState();
}

class _CardCaptureScreenState extends State<CardCaptureScreen> {
  final _picker = ImagePicker();
  bool _isLoading = false;
  String _loadingMsg = 'Processing card...';
  final List<Uint8List> _processedCards = [];

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: _isLoading,
      message: _loadingMsg,
      child: Scaffold(
        backgroundColor: AppTheme.surface,
        appBar: AppBar(
          title: Text(widget.cardType.name),
          actions: [
            if (_processedCards.isNotEmpty)
              TextButton(
                onPressed: _goToSheet,
                child: Text('Next (${_processedCards.length}) →',
                    style: TextStyle(fontWeight: FontWeight.w700, color: widget.cardType.color)),
              ),
          ],
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildCardIcon(),
                const SizedBox(height: 24),
                _buildInputOptions(),
                const SizedBox(height: 24),
                if (_processedCards.isNotEmpty) _buildAddedCards(),
                const SizedBox(height: 12),
                _buildTips(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCardIcon() {
    return Center(
      child: Container(
        width: 200, height: 126,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            widget.cardType.color.withOpacity(0.15),
            widget.cardType.color.withOpacity(0.05),
          ]),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: widget.cardType.color.withOpacity(0.3), width: 1.5),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(widget.cardType.icon, size: 40, color: widget.cardType.color),
            const SizedBox(height: 8),
            Text(widget.cardType.name,
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: widget.cardType.color)),
            const Text('85.6 x 54 mm',
                style: TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
          ],
        ),
      ),
    );
  }

  Widget _buildInputOptions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Add Card Image',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
        const SizedBox(height: 4),
        const Text('You can add multiple cards for one sheet',
            style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(child: _InputButton(
              icon: Icons.camera_alt_outlined, label: 'Camera', sublabel: 'Take photo',
              color: widget.cardType.color, onTap: _captureFromCamera,
            )),
            const SizedBox(width: 10),
            Expanded(child: _InputButton(
              icon: Icons.photo_library_outlined, label: 'Gallery', sublabel: 'Pick image',
              color: widget.cardType.color, onTap: _pickFromGallery,
            )),
          ],
        ),
      ],
    );
  }

  Widget _buildAddedCards() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Added Cards (${_processedCards.length})',
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
            TextButton(
              onPressed: () => setState(() => _processedCards.clear()),
              child: const Text('Clear all', style: TextStyle(color: AppTheme.error, fontSize: 13)),
            ),
          ],
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 100,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: _processedCards.length,
            itemBuilder: (context, index) => Container(
              margin: const EdgeInsets.only(right: 10),
              width: 160,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppTheme.border),
              ),
              child: Stack(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(9),
                    child: Image.memory(_processedCards[index], fit: BoxFit.cover, width: 160, height: 100),
                  ),
                  Positioned(
                    top: 4, right: 4,
                    child: GestureDetector(
                      onTap: () => setState(() => _processedCards.removeAt(index)),
                      child: Container(
                        width: 22, height: 22,
                        decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                        child: const Icon(Icons.close, color: Colors.white, size: 14),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _goToSheet,
            icon: const Icon(Icons.grid_view_outlined),
            label: Text('Generate Sheet (${_processedCards.length} cards)'),
            style: ElevatedButton.styleFrom(
              backgroundColor: widget.cardType.color,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTips() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: widget.cardType.color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: widget.cardType.color.withOpacity(0.15)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Tips for best results',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: widget.cardType.color)),
          const SizedBox(height: 8),
          const Text('Place card on plain dark background',
              style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
          const SizedBox(height: 3),
          const Text('Good even lighting, no glare',
              style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
          const SizedBox(height: 3),
          const Text('Keep card flat, capture full card in frame',
              style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
        ],
      ),
    );
  }

  Future<void> _captureFromCamera() async {
    setState(() { _isLoading = true; _loadingMsg = 'Opening camera...'; });
    try {
      final xFile = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 88,
        maxWidth: 1500,
      );
      if (xFile == null) { setState(() => _isLoading = false); return; }
      setState(() => _loadingMsg = 'Processing card...');
      final processed = await CardProcessingService.cropCard(File(xFile.path));
      if (mounted) setState(() { _processedCards.add(processed); _isLoading = false; });
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Camera error: $e'), backgroundColor: AppTheme.error),
        );
      }
    }
  }

  Future<void> _pickFromGallery() async {
    setState(() { _isLoading = true; _loadingMsg = 'Opening gallery...'; });
    try {
      final xFile = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 88,
        maxWidth: 1500,
      );
      if (xFile == null) { setState(() => _isLoading = false); return; }
      setState(() => _loadingMsg = 'Processing card...');
      final processed = await CardProcessingService.cropCard(File(xFile.path));
      if (mounted) setState(() { _processedCards.add(processed); _isLoading = false; });
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gallery error: $e'), backgroundColor: AppTheme.error),
        );
      }
    }
  }

  void _goToSheet() {
    if (_processedCards.isEmpty) return;
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => CardPreviewScreen(cardImages: List.from(_processedCards), cardType: widget.cardType),
    ));
  }
}

class _InputButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final String sublabel;
  final Color color;
  final VoidCallback onTap;

  const _InputButton({required this.icon, required this.label, required this.sublabel, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.2), width: 1.5),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 26),
            const SizedBox(height: 6),
            Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: color)),
            Text(sublabel, style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
          ],
        ),
      ),
    );
  }
}

import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';

class ImageCompressUtil {
  /// Compress bytes → bytes. Max 1500px wide, JPEG quality 85.
  /// Safe for large camera images (8–20 MB). Runs in compute isolate.
  static Future<Uint8List> compressInputImage(Uint8List inputBytes) async {
    return compute(_compressBytesIsolate, inputBytes);
  }

  static Uint8List _compressBytesIsolate(Uint8List inputBytes) {
    img.Image? decoded = img.decodeImage(inputBytes);
    if (decoded == null) return inputBytes; // decode failed — return original
    const maxWidth = 1500;
    if (decoded.width > maxWidth) {
      decoded = img.copyResize(decoded, width: maxWidth, interpolation: img.Interpolation.linear);
    }
    return Uint8List.fromList(img.encodeJpg(decoded, quality: 85));
  }

  /// Compress a File → new File. Max 2000px wide, JPEG quality 90.
  static Future<File> compressToMaxWidth(File inputFile, {int maxWidth = 2000}) async {
    final inputPath = inputFile.path;
    final tempDir = await getTemporaryDirectory();
    final outputPath = '${tempDir.path}/compressed_${DateTime.now().millisecondsSinceEpoch}.jpg';
    await compute(_compressArgs, {'input': inputPath, 'output': outputPath, 'maxWidth': maxWidth});
    return File(outputPath);
  }

  static void _compressArgs(Map<String, dynamic> args) {
    _compressIsolate(args['input'] as String, args['output'] as String, args['maxWidth'] as int);
  }

  static void _compressIsolate(String inputPath, String outputPath, int maxWidth) {
    final bytes = File(inputPath).readAsBytesSync();
    img.Image? decoded = img.decodeImage(bytes);
    if (decoded == null) { File(outputPath).writeAsBytesSync(bytes); return; }
    if (decoded.width > maxWidth) {
      decoded = img.copyResize(decoded, width: maxWidth, interpolation: img.Interpolation.linear);
    }
    File(outputPath).writeAsBytesSync(img.encodeJpg(decoded, quality: 90));
  }
}

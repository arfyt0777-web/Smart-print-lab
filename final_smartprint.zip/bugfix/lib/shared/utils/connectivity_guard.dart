import 'dart:io';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';

/// Thrown when device has no real internet access.
class NoInternetException implements Exception {
  final String message;
  const NoInternetException([this.message = 'No internet connection.\nPlease check your WiFi or mobile data and try again.']);
  @override
  String toString() => message;
}

/// Checks connectivity type, then performs a real ping.
/// Throws [NoInternetException] if either check fails.
Future<void> ensureInternetOrThrow() async {
  // Step 1 — connectivity type check
  final results = await Connectivity().checkConnectivity();
  final hasInterface = results.any((r) =>
      r == ConnectivityResult.mobile ||
      r == ConnectivityResult.wifi ||
      r == ConnectivityResult.ethernet);

  if (!hasInterface) {
    throw const NoInternetException();
  }

  // Step 2 — real ping to verify actual internet (not just connected to router)
  try {
    final result = await InternetAddress.lookup('google.com')
        .timeout(const Duration(seconds: 3));
    if (result.isEmpty || result.first.rawAddress.isEmpty) {
      throw const NoInternetException(
        'Connected to network but no internet access.\nPlease check your connection and try again.',
      );
    }
  } on SocketException {
    throw const NoInternetException(
      'No internet access.\nPlease check your connection and try again.',
    );
  } on Exception {
    throw const NoInternetException(
      'Server timeout.\nPlease check your connection and try again.',
    );
  }
}

/// Shows a non-dismissible error dialog. Workflow stops after this.
Future<void> showErrorDialog(BuildContext context, String message) {
  return showDialog(
    context: context,
    barrierDismissible: false,
    builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: const Row(children: [
        Icon(Icons.error_outline, color: Colors.red, size: 24),
        SizedBox(width: 10),
        Text('Error', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
      ]),
      content: Text(message, style: const TextStyle(fontSize: 14, height: 1.5)),
      actions: [
        ElevatedButton(
          onPressed: () => Navigator.of(context).pop(),
          style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
          child: const Text('OK'),
        ),
      ],
    ),
  );
}

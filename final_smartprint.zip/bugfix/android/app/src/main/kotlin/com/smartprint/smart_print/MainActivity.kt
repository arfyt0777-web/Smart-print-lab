package com.smartprint.smart_print
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()

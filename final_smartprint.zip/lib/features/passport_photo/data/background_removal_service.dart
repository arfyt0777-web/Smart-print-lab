import 'dart:io';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import 'package:image/image.dart' as img;
import '../../../core/config/app_config.dart';

class BackgroundRemovalService {
  static const int _timeoutSeconds = 30;

  /// Remove background using remove.bg API (fast — 2-3 seconds)
  /// Falls back to local color-based removal if API fails
  static Future<Uint8List> removeBackground(
    File imageFile, {
    void Function(String)? onStatusUpdate,
  }) async {
    final keys = AppConfig.removeBgApiKeys;

    // Try remove.bg API first
    if (keys.isNotEmpty) {
      onStatusUpdate?.call('Removing background...');
      try {
        final result = await _tryRemoveBgApi(imageFile, keys);
        if (result != null) return result;
      } catch (_) {}
    }

    // Fast local fallback
    onStatusUpdate?.call('Processing image...');
    return await _localBackgroundRemoval(imageFile);
  }

  static Future<Uint8List?> _tryRemoveBgApi(File imageFile, List<String> keys) async {
    final extension = imageFile.path.split('.').last.toLowerCase();
    final mimeType = extension == 'png' ? 'image/png' : 'image/jpeg';

    final dio = Dio(BaseOptions(
      connectTimeout: const Duration(seconds: _timeoutSeconds),
      receiveTimeout: const Duration(seconds: _timeoutSeconds),
      responseType: ResponseType.bytes,
    ));

    try {
      for (final key in keys) {
        if (key.length < 10) continue;
        try {
          final formData = FormData.fromMap({
            'image_file': await MultipartFile.fromFile(
              imageFile.path,
              filename: 'photo.$extension',
              contentType: DioMediaType.parse(mimeType),
            ),
            'size': 'auto',
          });

          final response = await dio.post(
            '${AppConfig.removeBgBaseUrl}/removebg',
            data: formData,
            options: Options(headers: {'X-Api-Key': key}),
          );

          if (response.statusCode == 200) {
            return Uint8List.fromList(response.data as List<int>);
          }
        } on DioException catch (e) {
          final status = e.response?.statusCode;
          if (status == 403 || status == 402) return null;
          if (status == 429) break;
        }
      }
    } finally {
      dio.close();
    }
    return null;
  }

  /// Fast local background removal using flood-fill
  static Future<Uint8List> _localBackgroundRemoval(File imageFile) async {
    final bytes = await imageFile.readAsBytes();
    img.Image? original = img.decodeImage(bytes);
    if (original == null) throw Exception('Cannot decode image');

    final rgba = original.convert(numChannels: 4);
    final w = rgba.width;
    final h = rgba.height;

    // Sample corners to detect background color
    final corners = [
      rgba.getPixel(0, 0),
      rgba.getPixel(w - 1, 0),
      rgba.getPixel(0, h - 1),
      rgba.getPixel(w - 1, h - 1),
    ];
    final bgColor = corners.first;

    // Flood fill from all 4 corners
    const tolerance = 35.0;
    _floodFill(rgba, 0, 0, bgColor, tolerance);
    _floodFill(rgba, w - 1, 0, bgColor, tolerance);
    _floodFill(rgba, 0, h - 1, bgColor, tolerance);
    _floodFill(rgba, w - 1, h - 1, bgColor, tolerance);

    return Uint8List.fromList(img.encodePng(rgba));
  }

  static void _floodFill(img.Image image, int startX, int startY, img.Color targetColor, double tolerance) {
    final w = image.width;
    final h = image.height;
    final transparent = img.ColorRgba8(0, 0, 0, 0);
    final queue = <List<int>>[[startX, startY]];
    final visited = List.generate(h, (_) => List.filled(w, false));
    visited[startY][startX] = true;

    while (queue.isNotEmpty) {
      final point = queue.removeAt(0);
      final x = point[0];
      final y = point[1];
      final pixel = image.getPixel(x, y);
      if (pixel.a == 0) continue;
      if (_colorDist(pixel, targetColor) > tolerance * tolerance) continue;
      image.setPixel(x, y, transparent);

      for (final n in [[x-1,y],[x+1,y],[x,y-1],[x,y+1]]) {
        final nx = n[0]; final ny = n[1];
        if (nx >= 0 && nx < w && ny >= 0 && ny < h && !visited[ny][nx]) {
          visited[ny][nx] = true;
          queue.add([nx, ny]);
        }
      }
    }
  }

  static double _colorDist(img.Color a, img.Color b) {
    final dr = (a.r - b.r).toDouble();
    final dg = (a.g - b.g).toDouble();
    final db = (a.b - b.b).toDouble();
    return dr*dr + dg*dg + db*db;
  }
}

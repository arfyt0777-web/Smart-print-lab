import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import '../../../core/config/app_config.dart';

class SheetGeneratorService {
  static Future<Uint8List> generateSheet({
    required Uint8List subjectPng,
    required Color bgColor,
    required int photoCount,
    int borderPx = 0,
    bool useOriginalBg = false,
  }) async {
    final args = _SheetArgs(
      subjectPng: subjectPng,
      r: bgColor.red, g: bgColor.green, b: bgColor.blue,
      photoCount: photoCount,
      passportW: AppConfig.passportWidthPx,
      passportH: AppConfig.passportHeightPx,
      sheetW: AppConfig.sheetWidthPx,
      sheetH: AppConfig.sheetHeightPx,
      spacing: AppConfig.photoSpacingPx,
      borderPx: borderPx,
      useOriginalBg: useOriginalBg,
    );
    return _generateIsolate(args);
  }

  static Uint8List _generateIsolate(_SheetArgs a) {
    img.Image? subject = img.decodeImage(a.subjectPng);
    if (subject == null) throw Exception('Could not decode subject image');

    final img.Image passportPhoto;
    if (a.useOriginalBg) {
      // Keep original colours — just ensure RGB
      passportPhoto = subject.convert(numChannels: 3);
    } else {
      subject = subject.convert(numChannels: 4);
      passportPhoto = _composeSinglePhoto(subject, a.r, a.g, a.b);
    }

    // Fit inside passport dimensions — preserve aspect ratio, never stretch
    final srcW = passportPhoto.width;
    final srcH = passportPhoto.height;
    final scaleW = a.passportW / srcW;
    final scaleH = a.passportH / srcH;
    final scale = scaleW < scaleH ? scaleW : scaleH;
    final fitW = (srcW * scale).round();
    final fitH = (srcH * scale).round();

    final scaled = img.copyResize(passportPhoto, width: fitW, height: fitH, interpolation: img.Interpolation.linear);

    final passportCanvas = img.Image(width: a.passportW, height: a.passportH, numChannels: 3);
    img.fill(passportCanvas, color: img.ColorRgb8(255, 255, 255));
    img.compositeImage(passportCanvas, scaled,
        dstX: ((a.passportW - fitW) / 2).round(),
        dstY: ((a.passportH - fitH) / 2).round());

    // Add border if requested
    if (a.borderPx > 0) {
      _drawBorder(passportCanvas, a.borderPx);
    }

    final layout = _computeLayout(a.photoCount);
    final cols = layout[0];
    final rows = layout[1];

    final sheet = img.Image(width: a.sheetW, height: a.sheetH, numChannels: 3);
    img.fill(sheet, color: img.ColorRgb8(255, 255, 255));

    final totalW = cols * a.passportW + (cols - 1) * a.spacing;
    final totalH = rows * a.passportH + (rows - 1) * a.spacing;
    final startX = ((a.sheetW - totalW) / 2).round();
    final startY = ((a.sheetH - totalH) / 2).round();

    int count = 0;
    for (int row = 0; row < rows && count < a.photoCount; row++) {
      for (int col = 0; col < cols && count < a.photoCount; col++) {
        final x = startX + col * (a.passportW + a.spacing);
        final y = startY + row * (a.passportH + a.spacing);
        img.compositeImage(sheet, passportCanvas, dstX: x, dstY: y);
        count++;
      }
    }
    return Uint8List.fromList(img.encodePng(sheet));
  }

  static img.Image _composeSinglePhoto(img.Image subject, int r, int g, int b) {
    final result = img.Image(width: subject.width, height: subject.height, numChannels: 3);
    for (int y = 0; y < subject.height; y++) {
      for (int x = 0; x < subject.width; x++) {
        final p = subject.getPixel(x, y);
        final alpha = p.a / 255.0;
        final fr = (p.r * alpha + r * (1 - alpha)).round().clamp(0, 255);
        final fg = (p.g * alpha + g * (1 - alpha)).round().clamp(0, 255);
        final fb = (p.b * alpha + b * (1 - alpha)).round().clamp(0, 255);
        result.setPixel(x, y, img.ColorRgb8(fr, fg, fb));
      }
    }
    return result;
  }

  static void _drawBorder(img.Image image, int thickness) {
    final c = img.ColorRgb8(0, 0, 0);
    for (int t = 0; t < thickness; t++) {
      for (int x = 0; x < image.width; x++) {
        image.setPixel(x, t, c);
        image.setPixel(x, image.height - 1 - t, c);
      }
      for (int y = 0; y < image.height; y++) {
        image.setPixel(t, y, c);
        image.setPixel(image.width - 1 - t, y, c);
      }
    }
  }

  static List<int> _computeLayout(int photoCount) {
    if (photoCount <= 2) return [2, 1];
    if (photoCount <= 4) return [2, 2];
    if (photoCount <= 6) return [3, 2];
    if (photoCount <= 8) return [4, 2];
    if (photoCount <= 10) return [5, 2];
    if (photoCount <= 12) return [4, 3];
    if (photoCount <= 16) return [4, 4];
    if (photoCount <= 20) return [5, 4];
    return [5, 6]; // max 30
  }
}

class _SheetArgs {
  final Uint8List subjectPng;
  final int r, g, b, photoCount;
  final int passportW, passportH, sheetW, sheetH, spacing, borderPx;
  final bool useOriginalBg;
  const _SheetArgs({
    required this.subjectPng,
    required this.r, required this.g, required this.b,
    required this.photoCount,
    required this.passportW, required this.passportH,
    required this.sheetW, required this.sheetH,
    required this.spacing,
    required this.borderPx,
    required this.useOriginalBg,
  });
}

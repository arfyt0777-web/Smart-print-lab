import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../shared/widgets/loading_overlay.dart';
import '../../data/background_removal_service.dart';
import 'sheet_screen.dart';

class BackgroundScreen extends StatefulWidget {
  final File imageFile;
  const BackgroundScreen({super.key, required this.imageFile});

  @override
  State<BackgroundScreen> createState() => _BackgroundScreenState();
}

class _BackgroundScreenState extends State<BackgroundScreen> {
  Uint8List? _processedPng;
  bool _isLoading = true;
  String _loadingMessage = 'Removing background…';
  Color _selectedBg = Colors.white;
  String? _errorMessage;
  bool _showOriginal = false;

  final List<_BgOption> _bgOptions = [
    _BgOption('White',      Colors.white),
    _BgOption('St. Blue',   const Color(0xFF1A56DB)),
    _BgOption('St. Red',    const Color(0xFFDC2626)),
    _BgOption('St. Green',  const Color(0xFF16A34A)),
    _BgOption('St. Yellow', const Color(0xFFF59E0B)),
    _BgOption('St. Purple', const Color(0xFF7C3AED)),
  ];

  @override
  void initState() {
    super.initState();
    _removeBackground();
  }

  Future<void> _removeBackground() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _processedPng = null;
      _loadingMessage = 'Trying AI background removal…';
    });
    try {
      final result = await BackgroundRemovalService.removeBackground(
        widget.imageFile,
        onStatusUpdate: (msg) {
          if (mounted) setState(() => _loadingMessage = msg);
        },
      );
      if (mounted) setState(() { _processedPng = result; _isLoading = false; });
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'Background removal failed:\n${e.toString()}';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: _isLoading,
      message: _loadingMessage,
      child: Scaffold(
        backgroundColor: AppTheme.surface,
        appBar: AppBar(
          title: const Text('Background Removal'),
          leading: const BackButton(),
        ),
        body: _errorMessage != null
            ? _buildError()
            : _processedPng == null
                ? const SizedBox()
                : _buildContent(),
      ),
    );
  }

  Widget _buildError() => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, color: AppTheme.error, size: 64),
          const SizedBox(height: 16),
          Text(_errorMessage!, textAlign: TextAlign.center,
              style: const TextStyle(color: AppTheme.textSecondary)),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: _removeBackground,
            icon: const Icon(Icons.refresh),
            label: const Text('Retry'),
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primary),
          ),
        ],
      ),
    ),
  );

  Widget _buildContent() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildPreview(),
          const SizedBox(height: 20),
          _buildBgOptions(),
          const SizedBox(height: 20),
          _buildCustomColor(),
          const SizedBox(height: 20),
          _buildNextButton(),
        ],
      ),
    );
  }

  Widget _buildPreview() {
    return GestureDetector(
      onLongPressStart: (_) => setState(() => _showOriginal = true),
      onLongPressEnd: (_) => setState(() => _showOriginal = false),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: _showOriginal
            ? Image.file(widget.imageFile, fit: BoxFit.contain)
            : Container(
                color: _selectedBg,
                child: Image.memory(_processedPng!, fit: BoxFit.contain),
              ),
      ),
    );
  }

  Widget _buildBgOptions() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Text('Background Color',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
      const SizedBox(height: 12),
      Wrap(
        spacing: 10,
        runSpacing: 10,
        children: _bgOptions.map((opt) => _ColorChip(
          label: opt.label,
          color: opt.color,
          selected: _selectedBg == opt.color,
          onTap: () => setState(() => _selectedBg = opt.color),
        )).toList(),
      ),
    ],
  );

  Widget _buildCustomColor() => OutlinedButton.icon(
    onPressed: _pickCustomColor,
    icon: Container(width: 18, height: 18,
        decoration: BoxDecoration(color: _selectedBg, shape: BoxShape.circle,
            border: Border.all(color: AppTheme.border))),
    label: const Text('Custom Color'),
  );

  Future<void> _pickCustomColor() async {
    Color temp = _selectedBg;
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Pick Background Color'),
        content: SingleChildScrollView(
          child: ColorPicker(
            pickerColor: temp,
            onColorChanged: (c) => temp = c,
            pickerAreaHeightPercent: 0.8,
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () { setState(() => _selectedBg = temp); Navigator.pop(context); },
            child: const Text('Select'),
          ),
        ],
      ),
    );
  }

  Widget _buildNextButton() => SizedBox(
    width: double.infinity,
    child: ElevatedButton.icon(
      onPressed: () => Navigator.push(context, MaterialPageRoute(
        builder: (_) => SheetScreen(
          processedPng: _processedPng!,
          bgColor: _selectedBg,
          originalFile: widget.imageFile,
        ),
      )),
      icon: const Icon(Icons.arrow_forward),
      label: const Text('Continue to Sheet'),
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 16),
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
      ),
    ),
  );
}

class _BgOption {
  final String label;
  final Color color;
  const _BgOption(this.label, this.color);
}

class _ColorChip extends StatelessWidget {
  final String label;
  final Color color;
  final bool selected;
  final VoidCallback onTap;
  const _ColorChip({required this.label, required this.color, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: selected ? AppTheme.primary : AppTheme.border,
          width: selected ? 2.5 : 1,
        ),
      ),
      child: Text(label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: color == Colors.white ? AppTheme.textPrimary : Colors.white,
          )),
    ),
  );
}

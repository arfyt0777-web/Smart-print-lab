class AppConfig {
  static const String _k1 = String.fromEnvironment('REMOVE_BG_API_KEY');
  static const String _k2 = String.fromEnvironment('REMOVE_BG_API_KEY_2');
  static const String _k3 = String.fromEnvironment('REMOVE_BG_API_KEY_3');
  static const String _k4 = String.fromEnvironment('REMOVE_BG_API_KEY_4');
  static const String _k5 = String.fromEnvironment('REMOVE_BG_API_KEY_5');

  static List<String> get removeBgApiKeys =>
      [_k1, _k2, _k3, _k4, _k5].where((k) => k.isNotEmpty).toList();

  static const String removeBgBaseUrl = 'https://api.remove.bg/v1.0';
  static const String appName = 'SmartPrint';
  static const String appVersion = '1.0.0';
  static const int passportWidthPx  = 413;
  static const int passportHeightPx = 531;
  static const int sheetWidthPx  = 1200;
  static const int sheetHeightPx = 1800;
  static const int photoSpacingPx = 20;
  static const int sheetPaddingPx = 30;
}

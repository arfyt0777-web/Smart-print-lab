import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';

/// Compresses and resizes image in a background isolate.
/// Max width 2000px — preserves aspect ratio.
/// Returns a new compressed File ready for processing.
class ImageCompressUtil {
  static Future<File> compressToMaxWidth(File inputFile, {int maxWidth = 2000}) async {
    final inputPath = inputFile.path;
    final tempDir = await getTemporaryDirectory();
    final outputPath =
        '${tempDir.path}/compressed_${DateTime.now().millisecondsSinceEpoch}.jpg';

    // Run decode + resize directly
    _compressIsolate(inputPath, outputPath, maxWidth);

    return File(outputPath);
  }

  /// Isolate entry — no Flutter bindings allowed here.
  static void _compressIsolate(String inputPath, String outputPath, int maxWidth) {
    final bytes = File(inputPath).readAsBytesSync();
    img.Image? decoded = img.decodeImage(bytes);
    if (decoded == null) {
      // If decode fails, just copy original
      File(outputPath).writeAsBytesSync(bytes);
      return;
    }

    // Only resize if larger than maxWidth
    img.Image result = decoded;
    if (decoded.width > maxWidth) {
      result = img.copyResize(
        decoded,
        width: maxWidth,
        interpolation: img.Interpolation.linear,
      );
    }

    final compressed = img.encodeJpg(result, quality: 90);
    File(outputPath).writeAsBytesSync(compressed);
  }
}
